import React, { useState, useEffect } from "react"

import { socket, startMicrophone } from "./client/webrtc/intercom"
import { setSocket, registerClient, attachMicrophone } from "./client/webrtc/clientHandshake"

import { ViewMode, Client, NetworkConfig, GPIOConfig } from "./types"

import HostView from "./components/HostView"

import {
  Radio,
  Maximize,
  Globe,
  Activity,
  Wifi,
  WifiOff
} from "lucide-react"

/* ---------------- GPIO ---------------- */

const INITIAL_GPIO: GPIOConfig[] = Array.from({ length: 8 }).map((_, i) => ({
  id: i,
  label: `GPIO OUT ${i + 1}`,
  ip: "192.168.1.50",
  port: 5000,
  protocol: "UDP",
  isActive: false
}))

/* ---------------- CLIENTS ---------------- */

const INITIAL_CLIENTS: Client[] = Array.from({ length: 64 }).map((_, i) => ({
  id: `client-${i}`,
  name: `CL ${String(i + 1).padStart(2, "0")}`,
  type: "aux",
  status: "offline",
  isTalking: false,
  isLatched: false,
  gain: 50,
  volume: 100,
  isMuted: false,
  isIFBActive: false,
  isBacktalkActive: false,
  isTBVActive: false,
  tbActive: new Array(8).fill(false),
  gpioAssignment: 0,
  code: "0000",
  order: i,
  hidden: false,
  color: "#71717a",
  levels: Array(8).fill(-60),
  micLevel: -60,
  auxLevel: -60,
  muteOnTalk: [false,false,true,true,true,true,true,true],
  openOnTalk: [false,false,false,false,false,false,false,false],
  ifbNames: Array.from({ length: 8 }).map((_, idx) => `IFB ${idx + 1}`),
  inputGains: Array(8).fill(50),
  videoSources: []
}))

/* ---------------- APP ---------------- */

const App: React.FC = () => {

  const [view] = useState<ViewMode>(() => {
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent)
    return isMobile ? ViewMode.MOBILE : ViewMode.HOST
  })

  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS)

  const [activeHostTab, setActiveHostTab] =
    useState<"grid" | "linking" | "video" | "setup">("grid")

  const [network, setNetwork] = useState<NetworkConfig>({
    ip: "127.0.0.1",
    subnet: "255.255.255.0",
    gateway: "0.0.0.0",
    port: 8080,
    danteMaster: false,
    encryptionKey: "",
    interfaceType: "REGULAR",
    activeSoundcard: "",
    deviceId: "easycom-host",
    inputCount: 2,
    outputCount: 2
  })

  const [gpioConfigs, setGpioConfigs] = useState<GPIOConfig[]>(INITIAL_GPIO)

  const [theme, setTheme] = useState<"orange" | "blue">("orange")
  const [hostName, setHostName] = useState("EASYCOM-HOST")
  const [isNetSynced, setIsNetSynced] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)

  /* ---------------- SERVER ---------------- */

  useEffect(() => {

    const interval = setInterval(() => {

      if (socket?.connected) {

        setIsNetSynced(true)

        setSocket(socket)

        registerClient({
          id: "host-ui",
          name: "EasyCom Host",
          type: "desktop"
        })

        attachMicrophone()

        clearInterval(interval)

      }

    }, 300)

    return () => clearInterval(interval)

  }, [])

  /* ---------------- MIC TEST ---------------- */

  const startMicTest = async () => {

    try {
      await startMicrophone()
      console.log("MIC WORKS")
    } catch (err) {
      console.error("MIC ERROR", err)
    }

  }

  /* ---------------- FULLSCREEN ---------------- */

  useEffect(() => {

    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement)
    }

    document.addEventListener("fullscreenchange", handleFsChange)

    return () =>
      document.removeEventListener("fullscreenchange", handleFsChange)

  }, [])

  const toggleFullscreen = () => {

    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
    } else {
      document.exitFullscreen()
    }

  }

  const themeColor = theme === "orange" ? "orange" : "blue"

  /* ---------------- RENDER ---------------- */

  return (

    <div className={`flex flex-col h-screen selection:bg-${themeColor}-500/30`}>

      {!isFullscreen && (

        <div className="flex items-center justify-between px-6 py-2 bg-black/40 border-b border-white/5">

          <div className="flex items-center gap-6">

            <div className="flex items-center gap-3">
              <div className={`p-1.5 rounded bg-${themeColor}-600`}>
                <Radio size={18} className="text-white"/>
              </div>

              <span className="font-bold text-white uppercase">
                Easy<span className={`text-${themeColor}-500`}>Com</span>
              </span>
            </div>

            <div className="h-6 w-px bg-white/10"/>

            <div className={`flex items-center gap-2 px-3 py-1 rounded-full border
              ${isNetSynced
                ? "bg-green-600/10 border-green-500/40 text-green-500"
                : "bg-red-600/10 border-red-500/40 text-red-500 animate-pulse"
              }`}>

              {isNetSynced ? <Wifi size={12}/> : <WifiOff size={12}/>}

              <span className="text-[9px] font-black uppercase">
                {isNetSynced ? "Sync Active" : "Disconnected"}
              </span>

            </div>

          </div>

          <div className="flex items-center gap-4">

            <div className="flex items-center gap-2 px-3 py-1.5 border rounded bg-black/40">
              <Globe size={12} className={`text-${themeColor}-500`} />
              <span className="text-[9px] font-black uppercase">
                {hostName}
              </span>
            </div>

            <button
              onClick={startMicTest}
              className="flex items-center gap-2 px-3 py-1.5 border rounded bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <Activity size={12}/>
              <span className="text-[9px] font-black uppercase">
                Test Mic
              </span>
            </button>

            <button
              onClick={toggleFullscreen}
              className="flex items-center gap-2 px-3 py-1.5 border rounded bg-zinc-800 text-zinc-400 hover:text-white"
            >
              <Maximize size={12}/>
              <span className="text-[9px] font-black uppercase">
                Fullscreen
              </span>
            </button>

          </div>

        </div>

      )}

      <main className="flex-1 overflow-hidden">

        {view === ViewMode.HOST && (

          <HostView
            activeTab={activeHostTab}
            setActiveTab={setActiveHostTab}

            clients={clients}

            updateClient={(id: string, u: Partial<Client>) =>
              setClients(prev => prev.map(c => c.id === id ? { ...c, ...u } : c))
            }

            deleteClients={(ids: string[]) =>
              setClients(prev => prev.filter(c => !ids.includes(c.id)))
            }

            updateMultipleClients={(ids: string[], u: Partial<Client>) =>
              setClients(prev => prev.map(c => ids.includes(c.id) ? { ...c, ...u } : c))
            }

            addClient={() =>
              setClients(prev => [
                ...prev,
                {
                  ...INITIAL_CLIENTS[0],
                  id: `client-${Date.now()}`,
                  name: `CL ${prev.length + 1}`
                }
              ])
            }

            network={network}
            setNetwork={setNetwork}

            theme={theme}
            setTheme={setTheme}

            hostName={hostName}
            setHostName={setHostName}

            gpioConfigs={gpioConfigs}
            setGpioConfigs={setGpioConfigs}

            typeColors={{
              mobile:"#ea580c",
              desktop:"#3b82f6",
              remote:"#8b5cf6",
              aux:"#10b981"
            }}
          />

        )}

      </main>

    </div>

  )

}

export default App