import { useState, useEffect, useCallback } from "react"
import { Server, RefreshCw, Radio, AlertCircle, CheckCircle, Loader } from "lucide-react"
import { socket } from "../client/webrtc/intercom"
import { subscribeBridge, startBridge, stopBridge } from "../client/audio/audioBridgeStore"

type ServerDevice = {
  index: number
  name: string
  channels: number
  sampleRate: number
  isApollo: boolean
}

type Props = {
  onStreamReady?: (stream: MediaStream) => void
  onStreamStopped?: () => void
}

export default function ServerCapturePanel({ onStreamReady, onStreamStopped }: Props) {
  const [serverStatus, setServerStatus] = useState<"checking" | "unavailable" | "ready">("checking")
  const [serverError, setServerError] = useState("")
  const [devices, setDevices] = useState<ServerDevice[]>([])
  const [selectedDevice, setSelectedDevice] = useState<number | null>(null)
  const [selectedChannel, setSelectedChannel] = useState(0)

  const [bridgeState, setBridgeState] = useState({
    status: "idle",
    level: 0,
    error: null as string | null,
    deviceName: "",
    stream: null as MediaStream | null
  })

  // 🔥 Subscribe to store – gets current state immediately on mount
  // NO cleanup that stops bridge – store is singleton and persists
  useEffect(() => {
    const unsub = subscribeBridge((s: any) => {
      setBridgeState({
        status: s.status,
        level: s.level,
        error: s.error,
        deviceName: s.deviceName,
        stream: s.stream
      })
      if (s.status === "active" && s.stream) {
        onStreamReady?.(s.stream)
      }
    })
    // Only unsubscribe the listener – do NOT stop the bridge
    return unsub
  }, [])

  const loadDevices = useCallback(() => {
    setServerStatus("checking")
    setServerError("")

    const timeout = setTimeout(() => {
      setServerStatus("unavailable")
      setServerError("Serveren svarer ikke – er audioCapture.ts tilføjet og serveren genstartet?")
    }, 5000)

    socket.emit("audio:devices:list", (res: any) => {
      clearTimeout(timeout)
      if (!res?.ok) {
        setServerStatus("unavailable")
        setServerError(res?.error ?? "Serveren svarer ikke")
        return
      }
      if (!res.devices?.length) {
        setServerStatus("unavailable")
        setServerError("Ingen lydenheder fundet via ffmpeg")
        return
      }
      setDevices(res.devices)
      setServerStatus("ready")
      const apollo = res.devices.find((d: ServerDevice) => d.isApollo)
      setSelectedDevice(apollo?.index ?? res.devices[0].index)
      setSelectedChannel(0)
    })
  }, [])

  // 🔥 Load devices on mount – NO cleanup that stops bridge
  useEffect(() => {
    loadDevices()
    // no return cleanup
  }, [loadDevices])

  const device = devices.find(d => d.index === selectedDevice)

  const handleStart = async () => {
    if (selectedDevice === null || !device) return
    try {
      await startBridge(selectedDevice, selectedChannel, device.name)
    } catch {}
  }

  const handleStop = async () => {
    await stopBridge()
    onStreamStopped?.()
  }

  const isActive = bridgeState.status === "active"
  const isStarting = bridgeState.status === "starting"
  const hasError = bridgeState.status === "error"
  const level = bridgeState.level

  return (
    <div className="rounded-xl overflow-hidden"
      style={{
        background: isActive ? "rgba(249,115,22,0.06)" : "rgba(255,255,255,0.03)",
        border: `1px solid ${isActive ? "rgba(249,115,22,0.4)" : hasError ? "rgba(239,68,68,0.25)" : "rgba(255,255,255,0.08)"}`
      }}>

      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3"
        style={{ borderBottom: "1px solid rgba(255,255,255,0.05)", background: "rgba(0,0,0,0.25)" }}>
        <div className="flex items-center gap-2.5">
          <Server size={14} className={isActive ? "text-orange-400" : "text-white/40"} />
          <div>
            <p className="text-xs font-bold text-white">Server Audio Bridge</p>
            <p className="text-[9px] text-white/30">
              ffmpeg → Core Audio → PCM → browser → WebRTC
              {isActive && <span className="text-orange-400 ml-1">· {bridgeState.deviceName}</span>}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {isActive && (
            <span className="text-[8px] px-2 py-0.5 rounded font-bold"
              style={{ background: "#22c55e20", color: "#22c55e" }}>AKTIV</span>
          )}
          {!isActive && serverStatus === "checking" && (
            <Loader size={12} className="text-white/30 animate-spin" />
          )}
          {!isActive && serverStatus !== "checking" && (
            <button onClick={loadDevices}
              className="p-1.5 rounded hover:bg-white/10 text-white/30 hover:text-white"
              title="Genindlæs">
              <RefreshCw size={12} />
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">

        {/* Checking */}
        {serverStatus === "checking" && (
          <div className="flex items-center gap-2 text-[10px] text-white/30 py-2">
            <Loader size={11} className="animate-spin shrink-0" />
            Tjekker server...
          </div>
        )}

        {/* Unavailable */}
        {serverStatus === "unavailable" && (
          <div className="space-y-3">
            <div className="px-3 py-2.5 rounded-lg flex items-start gap-2"
              style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.25)" }}>
              <AlertCircle size={13} className="text-red-400 shrink-0 mt-0.5" />
              <p className="text-[10px] text-red-300">{serverError}</p>
            </div>
            <div className="px-3 py-3 rounded-lg space-y-2"
              style={{ background: "rgba(0,0,0,0.4)", border: "1px solid rgba(255,255,255,0.08)" }}>
              <p className="text-[10px] font-bold text-white/50">Setup:</p>
              {[
                { step: "1", code: "brew install ffmpeg" },
                { step: "2", text: "Kopiér audioCapture.ts → server/src/audioCapture.ts" },
                { step: "3", code: "cd server && npm run dev" },
                { step: "4", text: "Klik genindlæs ovenfor" },
              ].map(item => (
                <div key={item.step} className="flex items-start gap-2">
                  <span className="w-4 h-4 rounded-full bg-white/10 flex items-center justify-center text-[8px] font-bold shrink-0 mt-0.5 text-white/30">
                    {item.step}
                  </span>
                  {item.code
                    ? <code className="text-[9px] px-2 py-0.5 rounded font-mono text-green-300"
                        style={{ background: "rgba(34,197,94,0.08)", border: "1px solid rgba(34,197,94,0.2)" }}>
                        {item.code}
                      </code>
                    : <span className="text-[9px] text-white/35">{item.text}</span>
                  }
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Ready */}
        {serverStatus === "ready" && (
          <>
            {hasError && bridgeState.error && (
              <div className="px-3 py-2 rounded flex items-start gap-2"
                style={{ background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)" }}>
                <AlertCircle size={11} className="text-red-400 shrink-0 mt-0.5" />
                <p className="text-[9px] text-red-400">{bridgeState.error}</p>
              </div>
            )}

            {/* Device + channel – only when not active/starting */}
            {!isActive && !isStarting && (
              <>
                <div>
                  <label className="text-[9px] text-white/30 uppercase tracking-widest mb-1.5 block">
                    Lydenhed
                  </label>
                  <select
                    value={selectedDevice ?? ""}
                    onChange={e => { setSelectedDevice(Number(e.target.value)); setSelectedChannel(0) }}
                    className="w-full bg-black border border-white/10 rounded-lg px-3 py-2 text-xs text-white">
                    {devices.map(d => (
                      <option key={d.index} value={d.index}>
                        {d.isApollo ? "🎛️ " : "🎙 "}{d.name} ({d.channels} kanaler)
                      </option>
                    ))}
                  </select>
                </div>

                {device && (
                  <div>
                    <label className="text-[9px] text-white/30 uppercase tracking-widest mb-1.5 block">
                      Kanal · {device.channels} tilgængelige
                    </label>
                    <div className="flex gap-1 flex-wrap">
                      {Array.from({ length: Math.min(device.channels, 16) }, (_, i) => (
                        <button key={i}
                          onClick={() => setSelectedChannel(i)}
                          className="px-2.5 py-1.5 rounded-lg text-[10px] font-bold"
                          style={selectedChannel === i
                            ? { background: "#f9731625", border: "1px solid #f97316", color: "#f97316" }
                            : { background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.35)" }}>
                          CH{i + 1}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Starting */}
            {isStarting && (
              <div className="flex items-center gap-2 text-[10px] text-white/40 py-1">
                <Loader size={11} className="animate-spin shrink-0 text-orange-400" />
                Starter – {bridgeState.deviceName} CH{selectedChannel + 1}...
              </div>
            )}

            {/* Level when active */}
            {isActive && (
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <p className="text-[9px] text-white/40">
                    {bridgeState.deviceName} CH{selectedChannel + 1}
                  </p>
                  <span className="text-[9px] font-mono"
                    style={{ color: level > 2 ? "#22c55e" : "rgba(255,255,255,0.2)" }}>
                    {level.toFixed(1)}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-6 bg-black rounded overflow-hidden">
                    <div className="h-full rounded transition-all duration-75"
                      style={{
                        width: `${Math.min(100, level)}%`,
                        background: level > 85 ? "#ef4444" : level > 60 ? "#eab308" : "#22c55e"
                      }} />
                  </div>
                  {level > 2
                    ? <CheckCircle size={14} className="text-green-400 shrink-0" />
                    : <AlertCircle size={14} className="text-white/15 shrink-0" />
                  }
                </div>
                {level > 2
                  ? <p className="text-[9px] text-green-400/70 mt-1.5">
                      ✅ Signal OK – tryk TALK ALL i Producer for at sende til clients
                    </p>
                  : <p className="text-[9px] text-yellow-400/60 mt-1.5">
                      Bridge aktiv men ingen lyd – tjek Apollo Console
                    </p>
                }
              </div>
            )}

            {/* Start / Stop */}
            <button
              onClick={isActive ? handleStop : handleStart}
              disabled={isStarting || selectedDevice === null}
              className="w-full py-3 rounded-xl text-sm font-black uppercase tracking-widest flex items-center justify-center gap-2"
              style={isActive
                ? { background: "#ef4444", color: "white" }
                : isStarting
                  ? { background: "rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.25)", cursor: "not-allowed" }
                  : { background: "#f97316", color: "white" }
              }>
              {isActive && <><Radio size={14} className="animate-pulse" /> Stop bridge</>}
              {isStarting && <><Loader size={14} className="animate-spin" /> Starter...</>}
              {!isActive && !isStarting && (
                <><Server size={14} /> Start · {device?.name ?? "..."} CH{selectedChannel + 1}</>
              )}
            </button>
          </>
        )}

      </div>
    </div>
  )
}
