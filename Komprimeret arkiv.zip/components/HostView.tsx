import React, { useState, useEffect, useRef } from "react"

import ClientStrip from "./ClientStrip"
import ChannelMixer from "./ChannelMixer"
import ProducerStrip from "./ProducerStrip"
import NetworkPanel from "./NetworkPanel"
import ClientLinking from "./ClientLinking"
import VideoTab from "./VideoTab"
import ConnectionsPopup from "./ConnectionsPopup"
import RoutingGraph from "./RoutingGraph"
import DragConnectionLayer from "./DragConnectionLayer"
import RoutingOverview from "./RoutingOverview"
import SnapshotPanel from "./SnapshotPanel"
import AudioIOPanel from "./AudioIOPanel"
import GroupPanel from "./GroupPanel"
import SignalChainDebugger from "./SignalChainDebugger"

import { socket } from "../client/webrtc/intercom"
import { ChannelMixerSettings, Client } from "../types"

import {
  Grid3X3, Plus, Search, Eye, EyeOff, Trash2,
  Keyboard, CheckSquare, Square, Smartphone,
  Monitor, Tablet, Video, Link2, Settings2,
  ZoomIn, ZoomOut, GitFork, Camera, Users, Bug
} from "lucide-react"

type ContextMenu = { clientId: string; x: number; y: number }
type SetupTab = "network" | "audio"

const CLIENT_TYPES = ["mobile", "desktop", "remote", "aux"] as const
const CLIENT_COLORS = [
  "#ef4444","#f97316","#eab308","#22c55e",
  "#06b6d4","#3b82f6","#a855f7","#ec4899",
  "#ffffff","#71717a"
]

const defaultMixer: ChannelMixerSettings = {
  gain: 80, mute: false, gateEnabled: false,
  gateThreshold: -50, eq: { low: 0, mid: 0, high: 0 }
}

const PRODUCER_ID = "producer-65"
const createProducerClient = (): Client => ({
  id: PRODUCER_ID, name: "PRODUCER", type: "desktop",
  status: "online", code: "PROD", order: -1,
  hidden: false, color: "#f97316",
  isTalking: false, isLatched: false, isMuted: false,
  isIFBActive: false, isBacktalkActive: false,
  gain: 80, volume: 100, levels: [], micLevel: 0, auxLevel: 0,
  tbActive: [], muteOnTalk: [], openOnTalk: [],
  ifbNames: [], videoSources: [],
  receiveChannels: [1,2,3,4,5,6,7,8]
})

const HostView = (props: any) => {

  const {
    activeTab, setActiveTab,
    clients: rawClients = [],
    hardware = [],
    updateClient = () => {},
    deleteClients = () => {},
    updateMultipleClients = () => {},
    addClient = () => {},
    network, setNetwork = () => {},
    videoStream1, videoStream2,
    startVideoStream, stopVideoStream,
    theme = "orange", myId
  } = props

  const themeColor = theme === "orange" ? "orange" : "blue"

  const producerExists = rawClients.some((c: Client) => c.id === PRODUCER_ID)
  const clients: Client[] = producerExists ? rawClients : [createProducerClient(), ...rawClients]
  const producerClient = clients.find((c: Client) => c.id === PRODUCER_ID) ?? createProducerClient()
  const regularClients = clients.filter((c: Client) => c.id !== PRODUCER_ID)

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedIds, setSelectedIds] = useState<string[]>([])
  const [lastSelectedId, setLastSelectedId] = useState<string | null>(null)
  const [mappingClientId, setMappingClientId] = useState<string | null>(null)
  const [popupClient, setPopupClient] = useState<any | null>(null)
  const [contextMenu, setContextMenu] = useState<ContextMenu | null>(null)
  const [cardScale, setCardScale] = useState(1)
  const [setupTab, setSetupTab] = useState<SetupTab>("network")
  const [connections, setConnections] = useState<any[]>([])
  const [editingNameId, setEditingNameId] = useState<string | null>(null)
  const [editingNameValue, setEditingNameValue] = useState("")
  const [mixerClientId, setMixerClientId] = useState<string | null>(null)
  const [showRoutingLines, setShowRoutingLines] = useState(true)
  const [showSignalDebug, setShowSignalDebug] = useState(false)

  // Drag-to-reorder
  const [gridOrder, setGridOrder] = useState<string[]>([])
  const dragItem = useRef<string | null>(null)
  const dragOverItem = useRef<string | null>(null)
  const contextMenuRef = useRef<HTMLDivElement>(null)

  /* ---------- GRID ORDER ---------- */

  useEffect(() => {
    setGridOrder(prev => {
      const ids = regularClients.map((c: Client) => c.id)
      const existing = prev.filter(id => ids.includes(id))
      const added = ids.filter((id: string) => !prev.includes(id))
      return [...existing, ...added]
    })
  }, [regularClients.length])

  const orderedRegularClients = gridOrder
    .map(id => regularClients.find((c: Client) => c.id === id))
    .filter(Boolean) as Client[]

  const handleGridDragStart = (id: string) => { dragItem.current = id }
  const handleGridDragEnter = (id: string) => { dragOverItem.current = id }
  const handleGridDragEnd = () => {
    if (!dragItem.current || !dragOverItem.current || dragItem.current === dragOverItem.current) {
      dragItem.current = null; dragOverItem.current = null; return
    }
    const newOrder = [...gridOrder]
    const from = newOrder.indexOf(dragItem.current)
    const to = newOrder.indexOf(dragOverItem.current)
    newOrder.splice(from, 1)
    newOrder.splice(to, 0, dragItem.current)
    setGridOrder(newOrder)
    dragItem.current = null; dragOverItem.current = null
  }

  /* ---------- CONNECTIONS ---------- */

  useEffect(() => {
    const load = (list?: any[]) => {
      if (Array.isArray(list)) { setConnections(list); return }
      socket.emit("connections:list", (res: any[]) => setConnections(Array.isArray(res) ? res : []))
    }
    load()
    socket.on("routing:update", load)
    return () => { socket.off("routing:update", load) }
  }, [])

  const handleUpdateClient = (id: string, updates: any) => {
    if (selectedIds.includes(id) && selectedIds.length > 1) {
      selectedIds.forEach(sid => updateClient(sid, updates))
    } else {
      updateClient(id, updates)
    }
  }

  const toggleMixer = (clientId: string) => setMixerClientId(prev => prev === clientId ? null : clientId)
  const mixerClient = clients.find((c: Client) => c.id === mixerClientId)
  const handleMixerChange = (s: ChannelMixerSettings) => {
    if (!mixerClientId) return
    updateClient(mixerClientId, { channelMixer: { ...(mixerClient?.channelMixer ?? {}), 1: s } })
  }

  const handleRestoreSnapshot = (snapshot: any) => {
    if (!window.confirm(`Gendan snapshot "${snapshot.name}"?`)) return
    snapshot.clients.forEach((c: any) => updateClient(c.id, c))
    snapshot.connections.forEach((c: any) => socket.emit("connection:create", { ...c, replace: true }))
  }

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (contextMenuRef.current && !contextMenuRef.current.contains(e.target as Node)) setContextMenu(null)
    }
    window.addEventListener("mousedown", handler)
    return () => window.removeEventListener("mousedown", handler)
  }, [])

  useEffect(() => {
    if (!mappingClientId) return
    const captureKey = (e: KeyboardEvent) => {
      e.preventDefault()
      updateClient(mappingClientId, { keyTrigger: e.code })
      setMappingClientId(null)
    }
    window.addEventListener("keydown", captureKey, true)
    return () => window.removeEventListener("keydown", captureKey, true)
  }, [mappingClientId])

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      const c = clients.find((x: Client) => x.keyTrigger === e.code)
      if (c) updateClient(c.id, { isTalking: true })
    }
    const up = (e: KeyboardEvent) => {
      const c = clients.find((x: Client) => x.keyTrigger === e.code)
      if (c) updateClient(c.id, { isTalking: false })
    }
    window.addEventListener("keydown", down)
    window.addEventListener("keyup", up)
    return () => { window.removeEventListener("keydown", down); window.removeEventListener("keyup", up) }
  }, [clients])

  const handleClientSelect = (id: string, e: React.MouseEvent) => {
    if (editingNameId) return
    const filtered = regularClients.filter((c: Client) => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
    const currentIdx = filtered.findIndex((c: Client) => c.id === id)
    if (e.shiftKey && lastSelectedId) {
      const lastIdx = filtered.findIndex((c: Client) => c.id === lastSelectedId)
      const [s, en] = [Math.min(lastIdx, currentIdx), Math.max(lastIdx, currentIdx)]
      setSelectedIds(filtered.slice(s, en + 1).map((c: Client) => c.id))
    } else if (e.ctrlKey || e.metaKey) {
      setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id])
    } else {
      setSelectedIds([id])
    }
    setLastSelectedId(id)
  }

  const filteredClients = regularClients.filter((c: Client) => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
  const allSelected = filteredClients.length > 0 && filteredClients.every((c: Client) => selectedIds.includes(c.id))
  const toggleSelectAll = () => {
    if (allSelected) setSelectedIds([])
    else setSelectedIds(filteredClients.map((c: Client) => c.id))
  }

  const handleRightClick = (e: React.MouseEvent, clientId: string) => {
    e.preventDefault(); e.stopPropagation()
    setContextMenu({ clientId, x: e.clientX, y: e.clientY })
  }

  const scaleUp = () => setCardScale(s => Math.min(2, parseFloat((s + 0.1).toFixed(1))))
  const scaleDown = () => setCardScale(s => Math.max(0.4, parseFloat((s - 0.1).toFixed(1))))

  const startRename = (c: any, e: React.MouseEvent) => {
    e.stopPropagation(); setEditingNameId(c.id); setEditingNameValue(c.name)
  }
  const saveRename = (id: string) => {
    if (editingNameValue.trim()) updateClient(id, { name: editingNameValue.trim() })
    setEditingNameId(null)
  }

  /* ---------- TABS ---------- */

  const renderTab = () => {
    switch (activeTab) {

      case "grid":
        return (
          <div className="relative w-full h-full overflow-auto p-3">

            <ProducerStrip
              client={producerClient}
              clients={regularClients}
              onUpdate={(u: any) => updateClient(PRODUCER_ID, u)}
              theme={theme}
            />

            {/* TOOLBAR */}
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <button onClick={scaleDown} className="p-1 bg-white/5 hover:bg-white/10 rounded">
                <ZoomOut size={14} />
              </button>
              <div className="w-24 h-1.5 bg-white/10 rounded overflow-hidden">
                <div className="h-full bg-zinc-400 rounded transition-all"
                  style={{ width: `${((cardScale - 0.4) / 1.6) * 100}%` }} />
              </div>
              <button onClick={scaleUp} className="p-1 bg-white/5 hover:bg-white/10 rounded">
                <ZoomIn size={14} />
              </button>
              <span className="text-[10px] text-white/30">{Math.round(cardScale * 100)}%</span>

              {/* Routing lines toggle */}
              <button
                onClick={() => setShowRoutingLines(p => !p)}
                className="ml-1 flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold transition-all"
                style={showRoutingLines
                  ? { background: "rgba(249,115,22,0.2)", border: "1px solid rgba(249,115,22,0.5)", color: "#f97316" }
                  : { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.3)" }}
                title="Vis/skjul forbindelseslinjer"
              >
                <GitFork size={11} />
                {showRoutingLines ? "Linjer ON" : "Linjer OFF"}
              </button>

              {/* Signal chain debug */}
              <button
                onClick={() => setShowSignalDebug(true)}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-bold"
                style={{ background: "rgba(234,179,8,0.15)", border: "1px solid rgba(234,179,8,0.35)", color: "#eab308" }}
                title="Signal chain debugger"
              >
                <Bug size={11} /> Signal debug
              </button>

              {selectedIds.length > 1 && (
                <span className={`ml-1 text-[10px] px-2 py-0.5 rounded bg-${themeColor}-600/30 text-${themeColor}-400`}>
                  ✏️ {selectedIds.length} valgt
                </span>
              )}

              <span className="text-[10px] text-white/15 ml-1">Træk kort for at omarrangere</span>
            </div>

            {/* CLIENT GRID */}
            <div
              className="grid gap-2"
              style={{ gridTemplateColumns: `repeat(auto-fill, minmax(${Math.round(80 * cardScale)}px, ${Math.round(80 * cardScale)}px))` }}
            >
              {orderedRegularClients.filter((c: Client) => !c.hidden).map((c: Client) => (
                <div
                  key={c.id}
                  draggable
                  onDragStart={() => handleGridDragStart(c.id)}
                  onDragEnter={() => handleGridDragEnter(c.id)}
                  onDragEnd={handleGridDragEnd}
                  onDragOver={e => e.preventDefault()}
                  onClick={e => handleClientSelect(c.id, e)}
                  onContextMenu={e => handleRightClick(e, c.id)}
                  style={{ width: `${Math.round(80 * cardScale)}px`, cursor: "grab" }}
                  className="active:cursor-grabbing"
                >
                  <ClientStrip
                    client={c}
                    isSelected={selectedIds.includes(c.id)}
                    onUpdate={(u: any) => handleUpdateClient(c.id, u)}
                    onHijack={() => {}}
                    onMapKey={() => setMappingClientId(c.id)}
                    theme={theme}
                    isMixerOpen={mixerClientId === c.id}
                    onToggleMixer={() => toggleMixer(c.id)}
                  />
                </div>
              ))}
            </div>

            {/* FLOATING MIXER */}
            {mixerClient && (
              <div className="fixed bottom-6 right-6 z-40">
                <ChannelMixer
                  channel={1}
                  clientId={mixerClient.id}
                  clientName={mixerClient.name}
                  settings={mixerClient.channelMixer?.[1] ?? defaultMixer}
                  onChange={handleMixerChange}
                  onClose={() => setMixerClientId(null)}
                  theme={theme}
                />
              </div>
            )}

            {showRoutingLines && <RoutingGraph clients={regularClients} />}
            {showRoutingLines && <DragConnectionLayer clients={regularClients} />}
          </div>
        )

      case "routing":
        return <RoutingOverview clients={clients} theme={theme} />

      case "groups":
        return <GroupPanel clients={regularClients} theme={theme} myId={myId} />

      case "linking":
        return (
          <ClientLinking
            clients={regularClients}
            updateClient={updateClient}
            remoteHosts={props.remoteHosts || []}
            theme={theme}
          />
        )

      case "snapshots":
        return (
          <SnapshotPanel
            clients={clients}
            connections={connections}
            onRestore={handleRestoreSnapshot}
            theme={theme}
          />
        )

      case "video":
        return (
          <VideoTab
            clients={regularClients} updateClient={updateClient}
            videoStream1={videoStream1} videoStream2={videoStream2}
            startVideoStream={startVideoStream} stopVideoStream={stopVideoStream}
            selectedIds={selectedIds} updateMultipleClients={updateMultipleClients}
            onClientMark={(id: any, e: any) => handleClientSelect(id, e)}
            theme={theme}
          />
        )

      case "setup":
        return (
          <div className="h-full flex flex-col">
            <div className="flex items-center justify-between px-4 pt-3 pb-0 shrink-0 border-b border-white/5">
              <div className="flex gap-1">
                {["network", "audio"].map(t => (
                  <button key={t} onClick={() => setSetupTab(t as SetupTab)}
                    className={`px-3 py-1.5 text-xs font-bold capitalize transition-colors
                      ${setupTab === t
                        ? `border-b-2 border-${themeColor}-500 text-${themeColor}-300`
                        : "text-white/40 hover:text-white/70"}`}>
                    {t === "network" ? "Netværk" : "Audio I/O"}
                  </button>
                ))}
              </div>
              {setupTab === "audio" && (
                <button
                  onClick={() => setShowSignalDebug(true)}
                  className="mb-1 flex items-center gap-1.5 px-3 py-1 rounded text-[10px] font-bold"
                  style={{ background: "rgba(234,179,8,0.15)", border: "1px solid rgba(234,179,8,0.35)", color: "#eab308" }}
                >
                  <Bug size={11} /> Signal Debugger
                </button>
              )}
            </div>
            <div className="flex-1 overflow-hidden">
              {setupTab === "network"
                ? <NetworkPanel
                    network={network} setNetwork={setNetwork}
                    remoteHosts={props.remoteHosts || []}
                    hardware={hardware}
                    refreshHardware={props.refreshHardware}
                    forceResumeAudio={props.forceResumeAudio}
                    globalInputLevel={props.globalInputLevel}
                  />
                : <AudioIOPanel clients={clients} theme={theme} />
              }
            </div>
          </div>
        )

      default: return null
    }
  }

  /* ---------- RENDER ---------- */

  return (
    <div className="h-full flex overflow-hidden">

      {/* SIDEBAR */}
      <div className="w-[260px] shrink-0 bg-zinc-950 border-r border-white/5 flex flex-col">

        <div className="p-3 border-b border-white/5 space-y-3">
          <button onClick={addClient}
            className={`w-full flex items-center justify-center gap-2 py-3 bg-${themeColor}-600 text-white font-black rounded`}>
            <Plus size={14} /> NEW CLIENT
          </button>
          <div className="relative">
            <Search size={12} className="absolute left-2 top-2" />
            <input value={searchTerm} onChange={e => setSearchTerm(e.target.value)}
              placeholder="Search clients"
              className="w-full pl-6 p-2 bg-black border border-white/10 rounded text-xs" />
          </div>
          <div className="flex gap-2">
            <button onClick={toggleSelectAll}
              className="flex-1 flex items-center justify-center gap-1 py-1 text-xs bg-white/5 hover:bg-white/10 rounded">
              {allSelected ? <><CheckSquare size={12} /> Deselect all</> : <><Square size={12} /> Select all</>}
            </button>
            {selectedIds.length > 0 && (
              <button onClick={() => deleteClients(selectedIds)}
                className="px-2 py-1 text-xs bg-red-600/20 hover:bg-red-600/40 text-red-400 rounded">
                <Trash2 size={12} />
              </button>
            )}
          </div>
        </div>

        {mappingClientId && (
          <div className={`mx-3 mt-2 px-3 py-2 rounded text-xs text-center bg-${themeColor}-600/30 border border-${themeColor}-500/50 animate-pulse`}>
            🎹 Tryk en tast...
            <button className="ml-2 text-white/50 hover:text-white" onClick={() => setMappingClientId(null)}>✕</button>
          </div>
        )}

        {selectedIds.length > 1 && (
          <div className={`mx-3 mt-2 px-3 py-2 rounded text-xs text-center bg-${themeColor}-900/40 border border-${themeColor}-700/40`}>
            ✏️ {selectedIds.length} clients valgt
          </div>
        )}

        <div className="flex-1 overflow-auto p-2 space-y-1">

          {/* PRODUCER row */}
          <div className="flex items-center justify-between px-3 py-2 rounded mb-1"
            style={{
              background: `${themeColor === "orange" ? "#f97316" : "#3b82f6"}15`,
              border: `1px solid ${themeColor === "orange" ? "#f97316" : "#3b82f6"}30`
            }}>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full"
                style={{ background: themeColor === "orange" ? "#f97316" : "#3b82f6" }} />
              <span className="text-xs font-black text-white">PRODUCER</span>
              <span className="text-[8px] text-white/30">CL 65</span>
            </div>
            <button onClick={e => { e.stopPropagation(); setPopupClient(producerClient) }}>
              <Link2 size={12} className="text-white/30 hover:text-white" />
            </button>
          </div>

          {filteredClients.map((c: Client) => {
            const isSelected = selectedIds.includes(c.id)
            const isRenaming = editingNameId === c.id
            return (
              <div key={c.id}
                className={`flex items-center justify-between px-3 py-2 rounded cursor-pointer
                  ${isSelected
                    ? `bg-${themeColor}-600/20 border border-${themeColor}-500/40`
                    : "bg-white/5 hover:bg-white/10"}`}
                onClick={e => handleClientSelect(c.id, e)}
                onContextMenu={e => handleRightClick(e, c.id)}
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  {isSelected
                    ? <CheckSquare size={14} className={`text-${themeColor}-500 shrink-0`} />
                    : <Square size={14} className="shrink-0" />}
                  {c.type === "mobile" && <Smartphone size={12} className="shrink-0" />}
                  {c.type === "desktop" && <Monitor size={12} className="shrink-0" />}
                  {c.type === "remote" && <Tablet size={12} className="shrink-0" />}
                  {c.color && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color }} />}
                  {isRenaming ? (
                    <input autoFocus value={editingNameValue}
                      onChange={e => setEditingNameValue(e.target.value)}
                      onBlur={() => saveRename(c.id)}
                      onKeyDown={e => {
                        if (e.key === "Enter") saveRename(c.id)
                        if (e.key === "Escape") setEditingNameId(null)
                      }}
                      onClick={e => e.stopPropagation()}
                      className="flex-1 min-w-0 text-xs bg-black border border-white/20 rounded px-1 py-0.5"
                    />
                  ) : (
                    <span className="text-xs font-bold truncate flex-1"
                      onDoubleClick={e => startRename(c, e)}>
                      {c.name}
                    </span>
                  )}
                </div>
                <div className="flex gap-1 shrink-0">
                  <button
                    onClick={e => { e.stopPropagation(); setMappingClientId(c.id) }}
                    className={`hover:text-yellow-400 ${c.keyTrigger ? "text-green-500" : ""}`}>
                    <Keyboard size={12} />
                  </button>
                  <button onClick={e => { e.stopPropagation(); updateClient(c.id, { hidden: !c.hidden }) }}>
                    {c.hidden ? <EyeOff size={12} /> : <Eye size={12} />}
                  </button>
                  <button onClick={e => { e.stopPropagation(); deleteClients([c.id]) }}>
                    <Trash2 size={12} />
                  </button>
                  <button onClick={e => { e.stopPropagation(); setPopupClient(c) }}>
                    <Link2 size={12} />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      {/* MAIN */}
      <div className="flex-1 flex flex-col min-w-0">
        <div className="h-14 flex items-center gap-1 border-b border-white/5 px-4 shrink-0 overflow-x-auto">
          {[
            { id: "grid",      icon: <Grid3X3 size={13} />,   label: "GRID" },
            { id: "routing",   icon: <GitFork size={13} />,   label: "ROUTING" },
            { id: "groups",    icon: <Users size={13} />,     label: "GRUPPER" },
            { id: "linking",   icon: <Link2 size={13} />,     label: "LINK" },
            { id: "snapshots", icon: <Camera size={13} />,    label: "SNAPSHOTS" },
            { id: "video",     icon: <Video size={13} />,     label: "VIDEO" },
            { id: "setup",     icon: <Settings2 size={13} />, label: "SETUP" },
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-bold transition-colors whitespace-nowrap
                ${activeTab === tab.id
                  ? `bg-${themeColor}-600/20 text-${themeColor}-300 border border-${themeColor}-500/30`
                  : "text-white/40 hover:text-white/70 hover:bg-white/5"}`}>
              {tab.icon} {tab.label}
            </button>
          ))}
        </div>
        <div className="flex-1 overflow-hidden min-w-0">{renderTab()}</div>
      </div>

      {/* CONNECTIONS POPUP */}
      {popupClient && (
        <ConnectionsPopup
          open={true}
          onClose={() => setPopupClient(null)}
          sourceClient={popupClient}
          clients={clients}
          onUpdateClient={updateClient}
        />
      )}

      {/* SIGNAL CHAIN DEBUGGER */}
      {showSignalDebug && (
        <SignalChainDebugger onClose={() => setShowSignalDebug(false)} />
      )}

      {/* CONTEXT MENU */}
      {contextMenu && (() => {
        const c = clients.find((cl: Client) => cl.id === contextMenu.clientId)
        if (!c) return null
        return (
          <div ref={contextMenuRef}
            className="fixed z-50 bg-zinc-900 border border-white/10 rounded-lg shadow-2xl p-3 w-52"
            style={{ top: contextMenu.y, left: contextMenu.x }}>
            <p className="text-xs font-bold text-white/50 mb-2 uppercase">{c.name}</p>
            <p className="text-[10px] text-white/30 mb-1">Type</p>
            <div className="grid grid-cols-4 gap-1 mb-3">
              {CLIENT_TYPES.map(type => (
                <button key={type}
                  onClick={() => { updateClient(c.id, { type }); setContextMenu(null) }}
                  className={`py-1 text-[9px] rounded capitalize
                    ${c.type === type ? `bg-${themeColor}-600 text-white` : "bg-white/10 hover:bg-white/20"}`}>
                  {type}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-white/30 mb-1">Farve</p>
            <div className="flex flex-wrap gap-1 mb-3">
              {CLIENT_COLORS.map(color => (
                <button key={color}
                  onClick={() => { updateClient(c.id, { color }); setContextMenu(null) }}
                  className="w-5 h-5 rounded-full border-2 transition-transform hover:scale-110"
                  style={{ background: color, borderColor: c.color === color ? "white" : "transparent" }} />
              ))}
            </div>
            <div className="border-t border-white/10 pt-2">
              <button
                onClick={() => { setPopupClient(c); setContextMenu(null) }}
                className="w-full flex items-center gap-2 px-2 py-1.5 rounded text-xs hover:bg-white/10 text-white/60 hover:text-white">
                <Link2 size={11} /> Vis forbindelser
              </button>
            </div>
          </div>
        )
      })()}

    </div>
  )
}

export default HostView
