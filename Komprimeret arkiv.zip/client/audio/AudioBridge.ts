/**
 * AudioBridge.ts
 * Placér i: client/audio/AudioBridge.ts
 */

import { socket } from "../webrtc/intercom"

type BridgeState = {
  ctx: AudioContext
  workletNode: AudioWorkletNode
  destination: MediaStreamAudioDestinationNode
  stream: MediaStream
  sampleRate: number
}

let bridge: BridgeState | null = null
let onLevelCallback: ((level: number) => void) | null = null
let rafId: number | null = null

const WORKLET_CODE = `
class PCMPlayerProcessor extends AudioWorkletProcessor {
  constructor() {
    super()
    this._queue = []
    this._chunkOffset = 0
    this.port.onmessage = (e) => {
      if (e.data.type === 'pcm') {
        this._queue.push(e.data.buffer)
      }
    }
  }

  process(inputs, outputs) {
    const output = outputs[0][0]
    if (!output) return true

    let filled = 0
    while (filled < output.length && this._queue.length > 0) {
      const chunk = this._queue[0]
      const available = chunk.length - this._chunkOffset
      const needed = output.length - filled

      if (available <= needed) {
        output.set(chunk.subarray(this._chunkOffset), filled)
        filled += available
        this._queue.shift()
        this._chunkOffset = 0
      } else {
        output.set(chunk.subarray(this._chunkOffset, this._chunkOffset + needed), filled)
        this._chunkOffset += needed
        filled = output.length
      }
    }

    for (let i = filled; i < output.length; i++) output[i] = 0
    return true
  }
}
registerProcessor('pcm-player', PCMPlayerProcessor)
`

export async function startAudioBridge(sampleRate: number): Promise<MediaStream> {
  if (bridge) stopAudioBridge()

  const ctx = new AudioContext({ sampleRate })
  await ctx.resume()

  const blob = new Blob([WORKLET_CODE], { type: "application/javascript" })
  const url = URL.createObjectURL(blob)
  await ctx.audioWorklet.addModule(url)
  URL.revokeObjectURL(url)

  const workletNode = new AudioWorkletNode(ctx, "pcm-player", {
    numberOfOutputs: 1,
    outputChannelCount: [1]
  })

  const analyser = ctx.createAnalyser()
  analyser.fftSize = 1024
  analyser.smoothingTimeConstant = 0.3

  const destination = ctx.createMediaStreamDestination()

  workletNode.connect(analyser)
  workletNode.connect(destination)

  // Level meter
  const buf = new Float32Array(analyser.fftSize)
  const tick = () => {
    analyser.getFloatTimeDomainData(buf)
    let sum = 0
    for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i]
    const rms = Math.min(100, Math.sqrt(sum / buf.length) * 400)
    onLevelCallback?.(rms)
    rafId = requestAnimationFrame(tick)
  }
  rafId = requestAnimationFrame(tick)

  bridge = { ctx, workletNode, destination, stream: destination.stream, sampleRate }

  socket.on("audio:pcm:chunk", handleChunk)

  // 🔥 Resume AudioContext when page becomes visible again
  document.addEventListener("visibilitychange", handleVisibility)

  console.log(`🎙 AudioBridge started @ ${sampleRate}Hz`)

  // 🔥 Verify the destination stream track is live
  const track = destination.stream.getAudioTracks()[0]
  console.log(`🎙 Destination track state: ${track?.readyState}`)

  return destination.stream
}

function handleVisibility() {
  if (document.visibilityState === "visible" && bridge?.ctx) {
    bridge.ctx.resume().catch(() => {})
  }
}

function handleChunk(buffer: ArrayBuffer | Buffer) {
  if (!bridge?.workletNode) return

  const int16 = new Int16Array(
    buffer instanceof ArrayBuffer ? buffer : (buffer as any).buffer
  )
  const float32 = new Float32Array(int16.length)
  for (let i = 0; i < int16.length; i++) {
    float32[i] = int16[i] / 32768.0
  }

  bridge.workletNode.port.postMessage({ type: "pcm", buffer: float32 }, [float32.buffer])
}

export function stopAudioBridge() {
  socket.off("audio:pcm:chunk", handleChunk)
  document.removeEventListener("visibilitychange", handleVisibility)
  if (rafId) { cancelAnimationFrame(rafId); rafId = null }
  if (bridge) {
    bridge.ctx.close().catch(() => {})
    bridge = null
  }
  console.log("⏹ AudioBridge stopped")
}

export function setAudioBridgeLevelCallback(cb: (level: number) => void) {
  onLevelCallback = cb
}

export function getAudioBridgeStream(): MediaStream | null {
  return bridge?.stream ?? null
}

// 🔥 Check if the bridge stream track is actually live
export function isAudioBridgeLive(): boolean {
  if (!bridge) return false
  const tracks = bridge.stream.getAudioTracks()
  return tracks.length > 0 && tracks[0].readyState === "live"
}

export function isAudioBridgeActive(): boolean {
  return bridge !== null
}
