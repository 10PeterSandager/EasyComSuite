import { Device } from "mediasoup-client"
import { socket } from "./intercom"

let device: Device
let sendTransport: any
let recvTransport: any
let _initialized = false
let _initializing = false

export function isMediasoupReady(): boolean {
  return _initialized && !!sendTransport
}

export async function initMediasoup() {
  if (_initialized) return
  if (_initializing) {
    await new Promise<void>(resolve => {
      const check = setInterval(() => {
        if (_initialized) { clearInterval(check); resolve() }
      }, 100)
    })
    return
  }

  _initializing = true

  try {
    if (!socket.connected) {
      await new Promise<void>(resolve => {
        socket.once("connect", resolve)
      })
    }

    const routerRtpCapabilities = await new Promise<any>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("getRouterRtpCapabilities timeout")), 8000)
      socket.emit("mediasoup:getRouterRtpCapabilities", (caps: any) => {
        clearTimeout(timeout)
        resolve(caps)
      })
    })

    device = new Device()
    await device.load({ routerRtpCapabilities })

    /* SEND TRANSPORT */
    const sendParams = await new Promise<any>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("createSendTransport timeout")), 8000)
      socket.emit("mediasoup:createTransport", { direction: "send" }, (params: any) => {
        clearTimeout(timeout)
        resolve(params)
      })
    })

    sendTransport = device.createSendTransport(sendParams)

    sendTransport.on("connect", ({ dtlsParameters }: any, cb: () => void) => {
      socket.emit("mediasoup:connectTransport", { transportId: sendTransport.id, dtlsParameters }, cb)
    })

    sendTransport.on("produce", ({ kind, rtpParameters }: any, cb: (p: { id: string }) => void) => {
      socket.emit("mediasoup:produce", { transportId: sendTransport.id, kind, rtpParameters },
        ({ id }: { id: string }) => cb({ id }))
    })

    /* RECV TRANSPORT */
    const recvParams = await new Promise<any>((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error("createRecvTransport timeout")), 8000)
      socket.emit("mediasoup:createTransport", { direction: "recv" }, (params: any) => {
        clearTimeout(timeout)
        resolve(params)
      })
    })

    recvTransport = device.createRecvTransport(recvParams)

    recvTransport.on("connect", ({ dtlsParameters }: any, cb: () => void) => {
      socket.emit("mediasoup:connectTransport", { transportId: recvTransport.id, dtlsParameters }, cb)
    })

    _initialized = true
    console.log("✅ Mediasoup client initialized")

  } finally {
    _initializing = false
  }
}

/* ---------- PRODUCE STREAM ---------- */

let currentProducer: any = null

export async function produceStream(stream: MediaStream): Promise<void> {
  if (!sendTransport) {
    console.log("produceStream: initializing transport first...")
    await initMediasoup()
  }

  if (!sendTransport) {
    throw new Error("sendTransport not ready after init")
  }

  const tracks = stream.getAudioTracks()
  if (tracks.length === 0) {
    throw new Error("no audio tracks in stream")
  }

  let track = tracks[0]

  // 🔥 Key fix: if track is ended, the stream from AudioWorklet destination
  // needs to be re-requested. We can't clone an ended track.
  if (track.readyState === "ended") {
    throw new Error(`audio track is ended (readyState: ${track.readyState}) – bridge stream needs restart`)
  }

  // 🔥 Clone the track so mediasoup can take ownership without affecting the source
  const clonedTrack = track.clone()

  if (clonedTrack.readyState !== "live") {
    clonedTrack.stop()
    throw new Error(`cloned track not live: ${clonedTrack.readyState}`)
  }

  if (currentProducer) {
    currentProducer.close()
    currentProducer = null
  }

  currentProducer = await sendTransport.produce({ track: clonedTrack })
  console.log("✅ Producing audio:", currentProducer.id)

  socket.emit("producer:register", {
    clientId: getClientId(),
    producerId: currentProducer.id
  })
}

export async function stopProducing() {
  if (currentProducer) {
    currentProducer.close()
    currentProducer = null
  }
}

/* ---------- GETTERS ---------- */

let _clientId = ""
export function setClientId(id: string) { _clientId = id }
export function getClientId() { return _clientId }

export function getDevice() { return device }
export function getSendTransport() { return sendTransport }
export function getRecvTransport() { return recvTransport }
