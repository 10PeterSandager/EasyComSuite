
const { app, BrowserWindow, systemPreferences } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 768,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      // Professional apps often need low latency audio
      backgroundThrottling: false,
    },
    // Professional macOS look: hide standard title bar, keep traffic lights
    titleBarStyle: 'hiddenInset',
    backgroundColor: '#0f1115',
    show: false
  });

  win.loadFile('index.html');

  win.once('ready-to-show', () => {
    win.show();
  });

  // Ensure microphone permissions are requested on macOS
  if (process.platform === 'darwin') {
    systemPreferences.askForMediaAccess('microphone').then(allowed => {
      if (!allowed) console.warn('Microphone access denied by user');
    });
  }
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
