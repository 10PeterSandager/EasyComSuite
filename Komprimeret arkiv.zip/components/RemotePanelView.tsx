import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Tablet, Wifi, Settings, Plus, Radio, Zap, Activity, X, ChevronRight, Speaker, Network, ShieldCheck, GripVertical, Trash2, Globe, Users, Link2, AlertTriangle, ChevronDown, Monitor, Maximize2, Mic, Anchor, UserCheck, Grid, Layers, GripHorizontal, Cpu, Laptop, Box, Search, Palette, RefreshCcw, Type, Trash, Volume2, CheckSquare, Square, Edit3, SlidersHorizontal } from 'lucide-react';
import { Client, MappedClient, RemoteHost, RemotePanelNode } from '../types';
import RemoteAppView from './RemoteAppView';

type PanelAction = 'map' | 'monitor' | 'advanced' | 'app' | null;

interface RemotePanelViewProps {
  clients: Client[];
  updateClient: (id: string, updates: Partial<Client>) => void;
  remoteHosts: RemoteHost[];
  panelMappings: Record<string, (MappedClient | null)[]>;
  setPanelMappings: React.Dispatch<React.SetStateAction<Record<string, (MappedClient | null)[]>>>;
  theme: 'orange' | 'blue';
  sharedStream1: MediaStream | null;
  sharedStream2: MediaStream | null;
  remotePanels: RemotePanelNode[];
  setRemotePanels: React.Dispatch<React.SetStateAction<RemotePanelNode[]>>;
  panelActiveKeys: Record<string, boolean[]>;
  setPanelActiveKeys: React.Dispatch<React.SetStateAction<Record<string, boolean[]>>>;
  onKeyChange?: (panelId: string, slotIdx: number, isDown: boolean) => void;
}

const RemotePanelView: React.FC<RemotePanelViewProps> = ({ 
  clients: localClients, updateClient, remoteHosts, panelMappings, setPanelMappings, theme,
  sharedStream1, sharedStream2, remotePanels, setRemotePanels, panelActiveKeys, setPanelActiveKeys, onKeyChange
}) => {
  const [activePanelId, setActivePanelId] = useState<string | null>(null);
  const [action, setAction] = useState<PanelAction>(null);
  const [isAddingPanel, setIsAddingPanel] = useState(false);
  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);
  
  const themeColor = theme === 'orange' ? 'orange' : 'blue';
  const activePanel = useMemo(() => remotePanels.find(p => p.id === activePanelId), [remotePanels, activePanelId]);

  const handleMockupInteraction = (mapping: MappedClient, slotIdx: number, isDown: boolean) => {
    if (!activePanelId) return;
    if (mapping.isGroupLatch) {
      if (isDown) {
        const members = mapping.memberIds || [];
        const targetClients = localClients.filter(c => members.includes(c.id));
        const anyOn = targetClients.some(c => c.isLatched);
        targetClients.forEach(c => updateClient(c.id, { isLatched: !anyOn }));
      }
      return;
    }

    const client = localClients.find(c => c.id === mapping.id);
    if (!client) return;

    if (mapping.isLatchCopy) {
      if (isDown) {
        const nextState = !client.isLatched;
        updateClient(client.id, { isLatched: nextState });
        onKeyChange?.(activePanelId, slotIdx, nextState);
      }
    } else {
      updateClient(client.id, { isTalking: isDown });
      onKeyChange?.(activePanelId, slotIdx, isDown);
    }
  };

  const addPanel = (type: 'pad' | 'streamdeck') => {
    const id = `rp-${Date.now()}`;
    const slotCount = 32;
    const newPanel: RemotePanelNode = {
      id, name: type === 'streamdeck' ? 'SD-STUDIO-1' : 'RP-PAD-1',
      ip: '0.0.0.0', type: 'Remote Device', panelType: type, status: 'connected',
      gridColumns: 8, slotCount, audioInputChannel: 1
    };
    setRemotePanels([...remotePanels, newPanel]);
    setPanelMappings(prev => ({ ...prev, [id]: Array(slotCount).fill(null) }));
    setPanelActiveKeys(prev => ({ ...prev, [id]: Array(slotCount).fill(false) }));
    setIsAddingPanel(false);
  };

  const closeOverlay = () => { setActivePanelId(null); setAction(null); };

  return (
    <div className="h-full flex flex-col p-8 bg-[#0a0c10] relative overflow-hidden">
      <div className="flex items-center justify-between mb-8 shrink-0">
        <div>
          <h2 className="text-3xl font-black text-white italic tracking-tighter uppercase">Remote Terminals</h2>
          <p className="text-sm text-zinc-500 font-bold uppercase tracking-widest mt-1 italic">Inter-Node Logic Management</p>
        </div>
        <button onClick={() => setIsAddingPanel(true)} className={`flex items-center gap-2 px-6 py-3 bg-${themeColor}-600 text-white font-black rounded-xl bevel uppercase tracking-widest text-xs shadow-lg`}>
          <Plus size={18} /> New Panel
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 overflow-y-auto">
        {remotePanels.map(panel => (
          <div key={panel.id} className="bg-zinc-900/50 border border-white/10 rounded-2xl p-6 bevel no-active group hover:border-zinc-700 transition-all">
            <div className="flex items-center justify-between mb-6">
               <div className="flex items-center gap-4">
                  <div className="bg-black/60 p-3 rounded-xl border border-white/5"><Tablet className={`text-${themeColor}-500`} size={24} /></div>
                  <div>
                    <h3 className="font-black text-white text-lg leading-tight uppercase">{panel.name}</h3>
                    <p className="text-[10px] text-zinc-500 font-mono italic">NET_PEER_LINKED</p>
                  </div>
               </div>
            </div>
            <div className="space-y-3">
              <button onClick={() => { setActivePanelId(panel.id); setAction('map'); }} className="w-full py-3 bg-zinc-800 border border-white/5 rounded-lg text-[10px] font-black text-zinc-400 uppercase tracking-widest hover:text-white bevel">Layout Workspace</button>
              <button onClick={() => { setActivePanelId(panel.id); setAction('app'); }} className="w-full py-2.5 bg-zinc-800 border border-white/5 rounded-lg text-[10px] font-black text-zinc-400 uppercase tracking-widest hover:text-white bevel flex items-center justify-center gap-2"><Monitor size={12} /> Launch Virtual PAD</button>
            </div>
          </div>
        ))}
      </div>

      {action && activePanel && (
        <div className="fixed inset-0 bg-black/95 z-[100] flex items-center justify-center p-6 backdrop-blur-md">
           <div className="w-full max-w-[1500px] h-full max-h-[95vh] bg-zinc-950 border border-white/10 rounded-3xl overflow-hidden flex flex-col bevel no-active">
              <div className="p-6 border-b border-white/10 bg-zinc-900 flex items-center justify-between shrink-0">
                  <h3 className="text-lg font-black text-white uppercase italic tracking-tighter">{activePanel.name}</h3>
                  <button onClick={closeOverlay} className="p-2 bg-zinc-800 rounded-full text-zinc-400 bevel"><X size={20} /></button>
              </div>
              <div className="flex-1 overflow-hidden flex relative">
                {action === 'app' && (
                  <RemoteAppView 
                    clients={localClients} updateClient={updateClient} 
                    mappings={panelMappings[activePanel.id] || []} theme={theme} 
                    panelName={activePanel.name} sharedStream1={sharedStream1} sharedStream2={sharedStream2} 
                    onTalkToggle={(idx, val) => onKeyChange?.(activePanel.id, idx, val)}
                  />
                )}
                {action === 'map' && <div className="p-10 text-white font-black uppercase">Grid Mapping Service // Drag & Drop from Sidebar</div>}
              </div>
           </div>
        </div>
      )}
    </div>
  );
};

export default RemotePanelView;