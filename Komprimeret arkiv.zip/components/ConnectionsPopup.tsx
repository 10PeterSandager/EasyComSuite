import { useEffect, useState } from "react"
import { socket } from "../client/webrtc/intercom"
import { Client } from "../types"
import { Unlink, RefreshCw, Pencil, Check, X, Headphones, Wifi, WifiOff } from "lucide-react"

type Connection = {
  from: string
  to: string
  channel: number
}

type Props = {
  open: boolean
  onClose: () => void
  sourceClient: Client
  clients: Client[]
  onUpdateClient: (id: string, updates: Partial<Client>) => void
}

const channelColors = [
  "#ef4444","#3b82f6","#22c55e","#a855f7",
  "#f97316","#06b6d4","#eab308","#ec4899"
]
const MAX_CH = 8

export default function ConnectionsPopup({
  open, onClose, sourceClient, clients, onUpdateClient
}: Props) {

  const [connections, setConnections] = useState<Connection[]>([])
  const [socketOk, setSocketOk] = useState(socket.connected)
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null)
  const [fromCh, setFromCh] = useState(1)
  const [toCh, setToCh] = useState(1)
  const [editingConn, setEditingConn] = useState<string | null>(null)
  const [editingCh, setEditingCh] = useState(1)

  /* ---------- SOCKET STATUS ---------- */

  useEffect(() => {
    const onConnect = () => setSocketOk(true)
    const onDisconnect = () => setSocketOk(false)
    socket.on("connect", onConnect)
    socket.on("disconnect", onDisconnect)
    setSocketOk(socket.connected)
    return () => {
      socket.off("connect", onConnect)
      socket.off("disconnect", onDisconnect)
    }
  }, [])

  /* ---------- LISTEN FOR ROUTING UPDATES ---------- */
  // 🔥 No callbacks – just listen to routing:update broadcast
  // Server sends this whenever anything changes, and we request it on open

  useEffect(() => {
    if (!open) {
      setSelectedTarget(null)
      setEditingConn(null)
      return
    }

    const onUpdate = (list: Connection[]) => {
      setConnections(Array.isArray(list) ? list : [])
    }

    socket.on("routing:update", onUpdate)

    // 🔥 Request current state – server broadcasts routing:update to everyone
    // This uses a simple emit with no callback dependency
    socket.emit("routing:request:all")

    return () => {
      socket.off("routing:update", onUpdate)
    }
  }, [open])

  if (!open) return null

  /* ---------- HELPERS ---------- */

  const chColor = (ch: number) => channelColors[(ch - 1) % channelColors.length]
  const connKey = (c: Connection) => `${c.from}-${c.to}-${c.channel}`

  const outgoing = connections.filter(c => c.from === sourceClient.id)
  const incoming = connections.filter(c => c.to === sourceClient.id)
  const total = outgoing.length + incoming.length

  const isConnected = (id: string) =>
    outgoing.some(c => c.to === id) || incoming.some(c => c.from === id)

  /* ---------- ACTIONS ---------- */

  const connect = () => {
    if (!selectedTarget || !socketOk) return
    // 🔥 Simple emit, no callback
    socket.emit("connection:create", {
      from: sourceClient.id,
      to: selectedTarget,
      channel: fromCh,
      toChannel: toCh
    })
    setSelectedTarget(null)
  }

  const disconnect = (conn: Connection) => {
    socket.emit("connection:remove", {
      from: conn.from,
      to: conn.to,
      channel: conn.channel
    })
  }

  const saveEdit = (conn: Connection) => {
    if (editingCh !== conn.channel) {
      socket.emit("connection:remove", { from: conn.from, to: conn.to, channel: conn.channel })
      socket.emit("connection:create", { from: conn.from, to: conn.to, channel: editingCh })
    }
    setEditingConn(null)
  }

  /* ---------- RECEIVE CHANNELS ---------- */

  const receiveChannels = sourceClient.receiveChannels ?? [1]

  const toggleReceiveCh = (ch: number) => {
    const updated = receiveChannels.includes(ch)
      ? receiveChannels.filter(c => c !== ch)
      : [...receiveChannels, ch].sort((a, b) => a - b)
    if (updated.length === 0) return
    onUpdateClient(sourceClient.id, { receiveChannels: updated })
  }

  /* ---------- RENDER ---------- */

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50">
      <div className="bg-zinc-900 border border-white/10 rounded-2xl w-[480px] shadow-2xl max-h-[90vh] flex flex-col">

        {/* HEADER */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/5 shrink-0">
          <div>
            <h2 className="text-white font-bold">{sourceClient.name}</h2>
            <div className="flex items-center gap-2 mt-0.5">
              {socketOk
                ? <><Wifi size={10} className="text-green-400" /><span className="text-[9px] text-green-400">Server forbundet</span></>
                : <><WifiOff size={10} className="text-red-400" /><span className="text-[9px] text-red-400">Ikke forbundet – tjek server på port 3000</span></>
              }
              <span className="text-[9px] text-white/30">· {total} aktive</span>
            </div>
          </div>
          <button
            onClick={() => socket.emit("routing:request:all")}
            className="p-1.5 bg-white/5 hover:bg-white/10 rounded"
          >
            <RefreshCw size={13} />
          </button>
        </div>

        <div className="flex-1 overflow-auto px-5 py-4 space-y-4">

          {/* RECEIVE CHANNELS */}
          <div className="p-3 bg-white/3 rounded-xl border border-white/5">
            <div className="flex items-center gap-2 mb-2">
              <Headphones size={12} className="text-white/40" />
              <span className="text-[10px] font-bold text-white/40 uppercase tracking-wider">
                {sourceClient.name} lytter på
              </span>
            </div>
            <div className="flex gap-1">
              {Array.from({ length: MAX_CH }, (_, i) => {
                const ch = i + 1
                const active = receiveChannels.includes(ch)
                return (
                  <button key={ch} onClick={() => toggleReceiveCh(ch)}
                    className="w-8 h-8 rounded-lg text-[10px] font-bold transition-all border"
                    style={active ? {
                      background: chColor(ch) + "40", borderColor: chColor(ch), color: chColor(ch)
                    } : {
                      background: "transparent", borderColor: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.2)"
                    }}>
                    {ch}
                  </button>
                )
              })}
            </div>
          </div>

          {/* ACTIVE CONNECTIONS */}
          {total > 0 && (
            <div className="space-y-1">
              <p className="text-[10px] text-white/30 uppercase tracking-wider mb-2">
                Aktive forbindelser
                <span className="ml-1 normal-case text-white/20">(klik CH for at ændre)</span>
              </p>
              {outgoing.map((conn, i) => {
                const other = clients.find(c => c.id === conn.to)
                const key = connKey(conn)
                const editing = editingConn === key
                return (
                  <div key={i} className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2 flex-1">
                      {editing ? (
                        <select autoFocus value={editingCh} onChange={e => setEditingCh(Number(e.target.value))}
                          className="text-[10px] bg-black border border-white/20 rounded px-1 py-0.5 w-16">
                          {Array.from({ length: MAX_CH }, (_, i) => <option key={i} value={i+1}>CH {i+1}</option>)}
                        </select>
                      ) : (
                        <button onClick={() => { setEditingConn(key); setEditingCh(conn.channel) }}
                          className="text-[10px] px-1.5 py-0.5 rounded font-bold hover:opacity-70"
                          style={{ background: chColor(conn.channel)+"30", color: chColor(conn.channel) }}>
                          CH {conn.channel}
                        </button>
                      )}
                      <span className="text-[10px] text-white/30">→</span>
                      <span className="text-xs font-bold">{other?.name ?? conn.to}</span>
                    </div>
                    <div className="flex gap-1">
                      {editing ? (
                        <>
                          <button onClick={() => saveEdit(conn)} className="p-1 rounded bg-green-600/30 text-green-400"><Check size={11}/></button>
                          <button onClick={() => setEditingConn(null)} className="p-1 rounded bg-white/5 text-white/40"><X size={11}/></button>
                        </>
                      ) : (
                        <>
                          <button onClick={() => { setEditingConn(key); setEditingCh(conn.channel) }} className="p-1 rounded bg-white/5 hover:bg-white/10 text-white/30"><Pencil size={11}/></button>
                          <button onClick={() => disconnect(conn)} className="p-1 rounded hover:bg-red-600/30 text-white/30 hover:text-red-400"><Unlink size={11}/></button>
                        </>
                      )}
                    </div>
                  </div>
                )
              })}
              {incoming.map((conn, i) => {
                const other = clients.find(c => c.id === conn.from)
                return (
                  <div key={i} className="flex items-center gap-2 px-3 py-2 bg-white/5 rounded-lg border border-white/5">
                    <div className="flex items-center gap-2 flex-1">
                      <span className="text-[10px] px-1.5 py-0.5 rounded font-bold"
                        style={{ background: chColor(conn.channel)+"30", color: chColor(conn.channel) }}>
                        CH {conn.channel}
                      </span>
                      <span className="text-[10px] text-white/30">←</span>
                      <span className="text-xs font-bold">{other?.name ?? conn.from}</span>
                    </div>
                    <button onClick={() => disconnect(conn)} className="p-1 rounded hover:bg-red-600/30 text-white/30 hover:text-red-400">
                      <Unlink size={11}/>
                    </button>
                  </div>
                )
              })}
            </div>
          )}

          {total === 0 && (
            <div className="py-3 text-center text-white/20 text-xs border border-white/5 rounded-lg">
              Ingen aktive forbindelser
            </div>
          )}

          {/* ADD CONNECTION */}
          <div className="border-t border-white/5 pt-4">
            <p className="text-[10px] text-white/30 uppercase tracking-wider mb-3">Tilføj forbindelse</p>

            {/* Channel row */}
            <div className="flex gap-2 mb-3 items-end">
              <div className="flex-1">
                <p className="text-[9px] text-white/30 mb-1">Fra kanal</p>
                <select value={fromCh} onChange={e => setFromCh(Number(e.target.value))}
                  className="w-full bg-black border border-white/10 rounded px-2 py-1.5 text-xs text-white">
                  {Array.from({ length: MAX_CH }, (_, i) => <option key={i} value={i+1}>CH {i+1}</option>)}
                </select>
              </div>
              <div className="text-white/20 pb-2">→</div>
              <div className="flex-1">
                <p className="text-[9px] text-white/30 mb-1">Til kanal</p>
                <select value={toCh} onChange={e => setToCh(Number(e.target.value))}
                  className="w-full bg-black border border-white/10 rounded px-2 py-1.5 text-xs text-white">
                  {Array.from({ length: MAX_CH }, (_, i) => <option key={i} value={i+1}>CH {i+1}</option>)}
                </select>
              </div>
            </div>

            {/* Client list */}
            <div className="space-y-1 max-h-[200px] overflow-auto pr-1 mb-3">
              {clients.filter(c => c.id !== sourceClient.id).map(c => {
                const connected = isConnected(c.id)
                const selected = selectedTarget === c.id
                return (
                  <div key={c.id}
                    onClick={() => !connected && setSelectedTarget(selected ? null : c.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm transition-all
                      ${connected
                        ? "opacity-40 cursor-default bg-zinc-800/50 border border-white/5"
                        : selected
                          ? "bg-orange-600/20 border border-orange-500 cursor-pointer text-white"
                          : "bg-zinc-800 text-zinc-400 hover:bg-zinc-700 border border-transparent cursor-pointer"
                      }`}
                  >
                    {c.color && <span className="w-2 h-2 rounded-full shrink-0" style={{ background: c.color }} />}
                    <span className="font-bold flex-1">{c.name}</span>
                    {connected && <span className="text-[9px] text-white/30">forbundet</span>}
                  </div>
                )
              })}
            </div>

            {/* Connect button */}
            {selectedTarget && (
              <button
                onClick={connect}
                disabled={!socketOk}
                className="w-full py-2.5 rounded-xl text-sm font-bold transition-all"
                style={socketOk ? {
                  background: "#f97316", color: "white", boxShadow: "0 0 16px #f9731640"
                } : {
                  background: "rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.3)"
                }}
              >
                Forbind {clients.find(c => c.id === selectedTarget)?.name} → CH {fromCh} / CH {toCh}
              </button>
            )}
          </div>

        </div>

        <div className="flex justify-end px-5 py-3 border-t border-white/5 shrink-0">
          <button onClick={onClose} className="px-4 py-2 text-sm bg-zinc-700 hover:bg-zinc-600 text-white rounded-lg">
            Luk
          </button>
        </div>

      </div>
    </div>
  )
}
