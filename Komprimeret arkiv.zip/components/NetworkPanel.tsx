import React, { useState } from 'react'
import { NetworkConfig, RemoteHost, HardwareInterface } from '../types'
import { Globe, RefreshCw, Users } from 'lucide-react'

interface NetworkPanelProps {
  network: NetworkConfig
  setNetwork: (n: NetworkConfig) => void
  remoteHosts: RemoteHost[]
  hardware: HardwareInterface[]
  refreshHardware: () => Promise<void>
  forceResumeAudio: () => Promise<void>
  globalInputLevel: number
}

const NetworkPanel: React.FC<NetworkPanelProps> = ({
  network,
  setNetwork,
  remoteHosts,
}) => {

  const [scanning, setScanning] = useState(false)

  const refreshHosts = () => {
    setScanning(true)
    setTimeout(() => setScanning(false), 2000)
  }

  const updateNet = (field: keyof NetworkConfig, value: any) => {
    setNetwork({ ...network, [field]: value })
  }

  return (
    <div className="h-full overflow-auto p-6 space-y-6">

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

        {/* NETWORK */}
        <div className="bg-zinc-900 p-6 rounded-2xl border border-white/5">

          <div className="flex items-center gap-3 mb-6">
            <Globe size={16} />
            <h3 className="text-sm font-bold text-white">Netværk</h3>
          </div>

          <div className="space-y-3">

            {[
              { label: "IP Adresse", field: "ip" as const, type: "text" },
              { label: "Subnet", field: "subnet" as const, type: "text" },
              { label: "Gateway", field: "gateway" as const, type: "text" },
              { label: "Port", field: "port" as const, type: "number" },
            ].map(({ label, field, type }) => (
              <div key={field}>
                <label className="text-[10px] text-white/30 uppercase tracking-wider">{label}</label>
                <input
                  type={type}
                  value={(network as any)[field]}
                  onChange={e => updateNet(field, type === "number" ? parseInt(e.target.value) : e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-black border border-white/10 rounded text-xs text-white"
                />
              </div>
            ))}

            <div>
              <label className="text-[10px] text-white/30 uppercase tracking-wider">Krypteringsnøgle</label>
              <input
                type="password"
                value={network.encryptionKey}
                onChange={e => updateNet('encryptionKey', e.target.value)}
                className="w-full mt-1 px-3 py-2 bg-black border border-white/10 rounded text-xs text-white"
              />
            </div>

          </div>

        </div>

        {/* PEERS */}
        <div className="bg-zinc-900 p-6 rounded-2xl border border-white/5 flex flex-col">

          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Users size={16} />
              <h3 className="text-sm font-bold text-white">Peers</h3>
            </div>
            <button
              onClick={refreshHosts}
              className="p-1.5 bg-white/5 hover:bg-white/10 rounded"
            >
              <RefreshCw size={13} className={scanning ? "animate-spin" : ""} />
            </button>
          </div>

          <div className="flex-1 space-y-2 overflow-auto">

            {remoteHosts.length === 0 && (
              <div className="text-center py-8 text-white/20 text-xs">
                Ingen peers fundet
              </div>
            )}

            {remoteHosts.map(host => (
              <div key={host.id} className="p-3 bg-zinc-800 rounded-lg border border-white/5">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-bold">{host.name}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded font-bold
                    ${host.status === "online" ? "bg-green-500/20 text-green-400" : "bg-white/5 text-white/30"}`}
                  >
                    {host.status}
                  </span>
                </div>
                <div className="text-xs text-white/30 mt-1">
                  {host.ip} · {host.clientsCount} clients
                </div>
              </div>
            ))}

          </div>

        </div>

      </div>

    </div>
  )
}

export default NetworkPanel
