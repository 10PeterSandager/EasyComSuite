import React, { useState, useRef, useEffect } from 'react'
import { Client } from '../types'
import { Play, Square, AlertCircle, Trash2, Check, X } from 'lucide-react'

interface VideoTabProps {
  clients: Client[]
  updateClient: (id: string, updates: Partial<Client>) => void
  theme: 'orange' | 'blue'
  videoStream1: MediaStream | null
  videoStream2: MediaStream | null
  videoStream3?: MediaStream | null
  videoStream4?: MediaStream | null
  startVideoStream: (channel: number, deviceId?: string) => Promise<void>
  stopVideoStream: (channel: number) => void
  selectedIds: string[]
  updateMultipleClients: (ids: string[], updates: Partial<Client>) => void
  onClientMark: (id: string, e: React.MouseEvent) => void
}

const VideoTab: React.FC<VideoTabProps> = ({
  clients,
  updateClient,
  theme,
  videoStream1,
  videoStream2,
  videoStream3,
  videoStream4,
  startVideoStream,
  stopVideoStream,
  selectedIds,
  updateMultipleClients,
  onClientMark
}) => {

  /* ✅ refs */
  const videoRef1 = useRef<HTMLVideoElement>(null)
  const videoRef2 = useRef<HTMLVideoElement>(null)
  const videoRef3 = useRef<HTMLVideoElement>(null)
  const videoRef4 = useRef<HTMLVideoElement>(null)

  const [selectedDevices, setSelectedDevices] = useState<Record<number, string>>({
    1: '', 2: '', 3: '', 4: ''
  })

  /* ---------------- VIDEO BIND ---------------- */

  useEffect(() => {

    const bind = (
      ref: React.RefObject<HTMLVideoElement>,
      stream?: MediaStream | null
    ) => {
      const el = ref.current
      if (!el) return

      if (stream) {
        el.srcObject = stream
        el.play().catch(() => {})
      } else {
        el.srcObject = null
      }
    }

    bind(videoRef1, videoStream1)
    bind(videoRef2, videoStream2)
    bind(videoRef3, videoStream3)
    bind(videoRef4, videoStream4)

  }, [videoStream1, videoStream2, videoStream3, videoStream4])

  /* ---------------- ROUTING ---------------- */

  const setSource = (clientId: string, slot: number, source: number | null) => {
    const c = clients.find(x => x.id === clientId)
    if (!c) return

    const sources = [...c.videoSources]

    while (sources.length < 2) sources.push(0)

    sources[slot] = source || 0

    const cleaned = sources.filter(s => s !== 0).slice(0, 2)

    updateClient(clientId, { videoSources: cleaned })
  }

  const clearSelected = () => {
    updateMultipleClients(selectedIds, { videoSources: [] })
  }

  /* ---------------- STREAM CARD ---------------- */

  const renderStream = (
    ch: number,
    stream: MediaStream | null | undefined,
    ref: React.RefObject<HTMLVideoElement>
  ) => {

    const active = !!stream

    return (
      <div className="flex flex-col gap-2">

        <div className="flex justify-between text-[10px] font-bold text-zinc-500">
          <span>INPUT {ch}</span>
          <span className={active ? 'text-green-500' : 'text-zinc-600'}>
            {active ? 'LIVE' : 'OFF'}
          </span>
        </div>

        <div className="relative h-40 bg-black rounded overflow-hidden border border-white/10">

          <video
            ref={ref}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />

          {!active && (
            <div className="absolute inset-0 flex items-center justify-center text-zinc-600">
              <AlertCircle size={20}/>
            </div>
          )}

          <div className="absolute top-2 right-2">

            {!active ? (
              <button
                onClick={() => startVideoStream(ch, selectedDevices[ch])}
                className="p-2 bg-green-600 text-white rounded"
              >
                <Play size={12}/>
              </button>
            ) : (
              <button
                onClick={() => stopVideoStream(ch)}
                className="p-2 bg-red-600 text-white rounded"
              >
                <Square size={12}/>
              </button>
            )}

          </div>

        </div>

      </div>
    )
  }

  /* ---------------- UI ---------------- */

  return (
    <div className="flex flex-col h-full p-6 gap-6">

      <div className="grid grid-cols-4 gap-4">
        {renderStream(1, videoStream1, videoRef1)}
        {renderStream(2, videoStream2, videoRef2)}
        {renderStream(3, videoStream3, videoRef3)}
        {renderStream(4, videoStream4, videoRef4)}
      </div>

      {selectedIds.length > 0 && (
        <button
          onClick={clearSelected}
          className="px-4 py-2 bg-red-600 text-white rounded flex gap-2 items-center"
        >
          <Trash2 size={14}/> CLEAR SELECTED
        </button>
      )}

      <div className="flex-1 overflow-auto">
        <table className="w-full text-xs">

          <thead>
            <tr className="text-zinc-500">
              <th className="text-left">Client</th>
              <th>OFF</th>
              <th>1</th>
              <th>2</th>
              <th>3</th>
              <th>4</th>
            </tr>
          </thead>

          <tbody>
            {clients.map(c => {

              const sources = [...c.videoSources]
              while (sources.length < 2) sources.push(0)

              return (
                <tr key={c.id} className="border-t border-white/5">

                  <td
                    onClick={(e)=>onClientMark(c.id,e)}
                    className="cursor-pointer font-bold"
                  >
                    {c.name}
                  </td>

                  {[0,1,2,3,4].map(src => {

                    const active = sources[0] === src

                    return (
                      <td
                        key={src}
                        onClick={()=>setSource(c.id,0,src===0?null:src)}
                        className="text-center cursor-pointer p-2"
                      >
                        {active ? <Check size={12}/> : <X size={12}/>}
                      </td>
                    )

                  })}

                </tr>
              )
            })}
          </tbody>

        </table>
      </div>

    </div>
  )
}

export default VideoTab