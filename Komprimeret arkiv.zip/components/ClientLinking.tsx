import React from "react"
import { Client } from "../types"

type Props = {
  clients: Client[]
  updateClient: (id: string, update: Partial<Client>) => void
  remoteHosts: any[]
  theme: string
}

const ClientLinking: React.FC<Props> = ({
  clients,
  updateClient,
  remoteHosts,
  theme
}) => {

  return (
    <div>

      <h2>Client Linking</h2>

      {clients.map(client => (

        <div key={client.id} style={{ marginBottom: 10 }}>

          <strong>{client.name}</strong>

          <button
            onClick={() =>
              updateClient(client.id, { isMuted: !client.isMuted })
            }
          >
            Toggle Mute
          </button>

        </div>

      ))}

    </div>
  )

}

export default ClientLinking