import React, { useState, useRef, useEffect } from "react"
import { ChannelMixerSettings } from "../types"
import { X, Radio, Zap, Hand, Mic } from "lucide-react"
import { socket, startToneLevelMeter, stopToneLevelMeter, subscribeToLevels } from "../client/webrtc/intercom"
import { produceStream, stopProducing } from "../client/webrtc/mediasoupClient"

type ToneMode = "auto" | "manual"

type Props = {
  channel: number
  clientName: string
  clientId: string
  settings: ChannelMixerSettings
  onChange: (s: ChannelMixerSettings) => void
  onClose: () => void
  theme?: "orange" | "blue"
}

/* ---------- KNOB ---------- */
function Knob({ value, min, max, onChange, color = "#f97316", size = 44, label, unit, centerZero }: {
  value: number; min: number; max: number; onChange: (v: number) => void
  color?: string; size?: number; label?: string; unit?: string; centerZero?: boolean
}) {
  const drag = useRef<{ y: number; v: number } | null>(null)
  const pct = (value - min) / (max - min)
  const angle = -150 + pct * 300
  const r = size / 2 - 4; const cx = size / 2; const cy = size / 2
  const rad = (d: number) => d * Math.PI / 180
  const sa = rad(-240); const ea = rad(angle - 90)
  const ax1 = cx + r * Math.cos(sa); const ay1 = cy + r * Math.sin(sa)
  const ax2 = cx + r * Math.cos(ea); const ay2 = cy + r * Math.sin(ea)
  const la = angle + 150 > 180 ? 1 : 0
  const ix = cx + (r - 3) * Math.cos(ea); const iy = cy + (r - 3) * Math.sin(ea)
  useEffect(() => {
    const mv = (e: MouseEvent) => {
      if (!drag.current) return
      onChange(Math.max(min, Math.min(max, Math.round((drag.current.v + (drag.current.y - e.clientY) / 150 * (max - min)) * 10) / 10)))
    }
    const up = () => { drag.current = null; document.body.style.cursor = ""; document.body.style.userSelect = "" }
    window.addEventListener("mousemove", mv); window.addEventListener("mouseup", up)
    return () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up) }
  }, [min, max, onChange])
  return (
    <div className="flex flex-col items-center gap-1 select-none">
      <div style={{ width: size, height: size, cursor: "ns-resize" }}
        onMouseDown={e => { e.preventDefault(); drag.current = { y: e.clientY, v: value }; document.body.style.cursor = "ns-resize"; document.body.style.userSelect = "none" }}
        onDoubleClick={() => centerZero && onChange(0)}>
        <svg width={size} height={size}>
          <circle cx={cx} cy={cy} r={r} fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="3" />
          {pct > 0 && <path d={`M ${ax1} ${ay1} A ${r} ${r} 0 ${la} 1 ${ax2} ${ay2}`} fill="none" stroke={color} strokeWidth="3" strokeLinecap="round" />}
          <circle cx={cx} cy={cy} r={r - 6} fill="#2a2a2a" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
          <circle cx={ix} cy={iy} r={2.5} fill={color} />
        </svg>
      </div>
      {label && <span className="text-[8px] text-white/30 uppercase tracking-widest">{label}</span>}
      {unit && <span className="text-[9px] font-mono" style={{ color }}>{value > 0 && centerZero ? "+" : ""}{value.toFixed(0)}{unit}</span>}
    </div>
  )
}

/* ---------- FADER ---------- */
function Fader({ value, onChange, color = "#f97316" }: { value: number; onChange: (v: number) => void; color?: string }) {
  const ref = useRef<HTMLDivElement>(null)
  const dragging = useRef(false)
  const pct = Math.max(0, Math.min(1, value / 100))
  const getV = (y: number) => {
    const r = ref.current?.getBoundingClientRect()
    if (!r) return value
    return Math.round((1 - Math.max(0, Math.min(1, (y - r.top) / r.height))) * 100)
  }
  useEffect(() => {
    const mv = (e: MouseEvent) => { if (dragging.current) onChange(getV(e.clientY)) }
    const up = () => { dragging.current = false; document.body.style.userSelect = "" }
    window.addEventListener("mousemove", mv); window.addEventListener("mouseup", up)
    return () => { window.removeEventListener("mousemove", mv); window.removeEventListener("mouseup", up) }
  }, [onChange])
  return (
    <div className="flex gap-2">
      <div className="flex flex-col justify-between py-1" style={{ height: 160 }}>
        {[100,75,50,25,0].map(m => <span key={m} className="text-[7px] text-white/20 font-mono leading-none">{m}</span>)}
      </div>
      <div ref={ref} style={{ height: 160, width: 24, background: "linear-gradient(to top,#0a0a0a,#1a1a1a)", borderRadius: 12, cursor: "pointer", position: "relative" }}
        onMouseDown={e => { onChange(getV(e.clientY)); dragging.current = true; document.body.style.userSelect = "none" }}>
        <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: `${pct*100}%`, borderRadius: 12, background: `linear-gradient(to top,${color}88,${color}44)` }} />
        <div style={{ position: "absolute", left: "50%", transform: "translateX(-50%)", top: `calc(${(1-pct)*100}% - 8px)`, width: 20, height: 16, borderRadius: 4, background: "linear-gradient(135deg,#666,#2a2a2a)", border: "1px solid rgba(255,255,255,0.2)" }}
          onMouseDown={e => { e.stopPropagation(); dragging.current = true; document.body.style.userSelect = "none" }} />
      </div>
    </div>
  )
}

/* ---------- VU ---------- */
function VU({ level }: { level: number }) {
  return (
    <div style={{ display: "flex", flexDirection: "column-reverse", gap: 2, height: 160, width: 12 }}>
      {Array.from({ length: 20 }, (_, i) => {
        const p = (i+1)/20; const on = level/100 >= p
        return <div key={i} style={{ flex: 1, borderRadius: 2, background: on ? p > 0.85 ? "#ef4444" : p > 0.6 ? "#eab308" : "#22c55e" : "rgba(255,255,255,0.05)" }} />
      })}
    </div>
  )
}

/* ============================================================
   GLOBAL TONE STATE
   ============================================================ */
let gCtx: AudioContext | null = null
let gOsc: OscillatorNode | null = null
let gGain: GainNode | null = null
let gAnalyser: AnalyserNode | null = null
let gDest: MediaStreamAudioDestinationNode | null = null
let gActive = false
let gClientId: string | null = null
let gMode: ToneMode = "auto"
let gIsProducing = false  // track if WebRTC is currently producing

const toneStateListeners = new Set<(active: boolean) => void>()
function notifyToneState(active: boolean) { toneStateListeners.forEach(fn => fn(active)) }

async function startTone(freq: number, wave: OscillatorType, level: number, clientId: string, mode: ToneMode): Promise<string | null> {
  if (gActive) stopTone()
  if (!clientId || clientId === "0") return `Ugyldigt clientId: "${clientId}"`
  try {
    const ctx = new AudioContext()
    await ctx.resume()
    if (ctx.state !== "running") return `AudioContext ikke aktiv: ${ctx.state}`
    gCtx = ctx; gMode = mode

    const osc = ctx.createOscillator()
    osc.type = wave; osc.frequency.value = freq; gOsc = osc

    const gain = ctx.createGain()
    gain.gain.value = level / 200; gGain = gain

    const analyser = ctx.createAnalyser()
    analyser.fftSize = 2048; analyser.smoothingTimeConstant = 0.3; gAnalyser = analyser

    const dest = ctx.createMediaStreamDestination(); gDest = dest

    osc.connect(gain)
    gain.connect(analyser)
    analyser.connect(ctx.destination)  // hear it locally
    analyser.connect(dest)             // WebRTC output

    osc.start()
    gActive = true; gClientId = clientId; gIsProducing = false
    notifyToneState(true)
    startToneLevelMeter(analyser, clientId)

    if (mode === "auto") {
      // Auto: start WebRTC immediately
      try {
        await produceStream(dest.stream)
        gIsProducing = true
        socket.emit("tone:start", { clientId, freq, wave, level, mode })
        console.log("🎵 Tone AUTO: producing to all connected")
      } catch (e) {
        console.error("Tone auto produce error:", e)
      }
    } else {
      // Manual: audio graph ready, WebRTC waits for PTT
      console.log("🎵 Tone MANUAL: ready, awaiting PTT press")
    }

    document.addEventListener("visibilitychange", onVis)
    return null
  } catch (e: any) {
    gActive = false; notifyToneState(false)
    return e?.message ?? "Fejl"
  }
}

function stopTone() {
  stopToneLevelMeter()
  if (gOsc) { try { gOsc.stop() } catch {} gOsc = null }
  if (gCtx) { gCtx.close().catch(() => {}); gCtx = null }
  gGain = null; gAnalyser = null; gDest = null
  if (gActive && gClientId) {
    socket.emit("tone:stop", { clientId: gClientId })
    if (gIsProducing) {
      stopProducing().catch(() => {})
      gIsProducing = false
    }
  }
  gActive = false; gClientId = null; gMode = "auto"
  notifyToneState(false)
  document.removeEventListener("visibilitychange", onVis)
}

// 🔥 PTT functions called from the mixer's own button
async function pttStart(): Promise<string | null> {
  if (!gActive || !gDest) return "Tone er ikke aktiv"
  if (gMode !== "manual") return null
  if (gIsProducing) return null
  try {
    console.log("🎵 PTT DOWN: start producing")
    await produceStream(gDest.stream)
    gIsProducing = true
    if (gClientId) socket.emit("tone:start", { clientId: gClientId, mode: "manual" })
    return null
  } catch (e: any) {
    return e?.message ?? "Fejl ved produceStream"
  }
}

async function pttStop() {
  if (!gIsProducing || gMode !== "manual") return
  console.log("🎵 PTT UP: stop producing")
  await stopProducing().catch(() => {})
  gIsProducing = false
  if (gClientId) socket.emit("tone:stop", { clientId: gClientId })
}

function onVis() { if (document.visibilityState === "visible" && gCtx) gCtx.resume().catch(() => {}) }

/* ---------- COMPONENT ---------- */
const ChannelMixer: React.FC<Props> = ({ channel, clientName, clientId, settings, onChange, onClose, theme = "orange" }) => {
  const color = theme === "orange" ? "#f97316" : "#3b82f6"
  const [showTone, setShowTone] = useState(true)
  const [toneActive, setToneActive] = useState(false)
  const [freq, setFreq] = useState(1000)
  const [wave, setWave] = useState<OscillatorType>("sine")
  const [toneLevel, setToneLevel] = useState(50)
  const [toneError, setToneError] = useState<string | null>(null)
  const [audioLevel, setAudioLevel] = useState(0)
  const [toneMode, setToneMode] = useState<ToneMode>("auto")
  // 🔥 PTT state – tracks if PTT is currently held
  const [pttHeld, setPttHeld] = useState(false)
  const pttRef = useRef(false)

  useEffect(() => {
    const listener = (active: boolean) => {
      setToneActive(active && gClientId === clientId)
      if (!active) { setPttHeld(false); pttRef.current = false }
    }
    toneStateListeners.add(listener)
    setToneActive(gActive && gClientId === clientId)
    return () => { toneStateListeners.delete(listener) }
  }, [clientId])

  useEffect(() => {
    return subscribeToLevels(levels => setAudioLevel(levels[clientId] ?? 0))
  }, [clientId])

  const update = (key: keyof ChannelMixerSettings, val: any) => onChange({ ...settings, [key]: val })

  const handleToneClick = async () => {
    setToneError(null)
    if (gActive) {
      stopTone()
    } else {
      const err = await startTone(freq, wave, toneLevel, clientId, toneMode)
      if (err) setToneError(err)
    }
  }

  // 🔥 PTT handlers – pointer capture so release always fires
  const handlePttDown = async (e: React.PointerEvent) => {
    e.currentTarget.setPointerCapture(e.pointerId)
    if (pttRef.current) return
    pttRef.current = true
    setPttHeld(true)
    const err = await pttStart()
    if (err) setToneError(err)
  }

  const handlePttUp = async (e: React.PointerEvent) => {
    e.currentTarget.releasePointerCapture(e.pointerId)
    pttRef.current = false
    setPttHeld(false)
    await pttStop()
  }

  const handleFreq = (f: number) => {
    setFreq(f)
    if (gOsc && gCtx) gOsc.frequency.setTargetAtTime(f, gCtx.currentTime, 0.01)
    if (gActive && gMode === "auto") socket.emit("tone:update", { clientId, freq: f })
  }

  const handleLevel = (l: number) => {
    setToneLevel(l)
    if (gGain && gCtx) gGain.gain.setTargetAtTime(l / 200, gCtx.currentTime, 0.01)
  }

  const handleWave = (w: OscillatorType) => { setWave(w); if (gOsc) gOsc.type = w }
  const WAVES: OscillatorType[] = ["sine", "square", "sawtooth", "triangle"]

  return (
    <div className="flex flex-col rounded-2xl overflow-hidden shadow-2xl select-none"
      style={{ width: 320, background: "linear-gradient(160deg,#1c1c1e,#111)", border: "1px solid rgba(255,255,255,0.08)", boxShadow: "0 32px 64px rgba(0,0,0,0.9)" }}>

      {/* HEADER */}
      <div className="flex items-center justify-between px-4 py-3"
        style={{ background: "linear-gradient(90deg,#0a0a0a,#151515)", borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full" style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
          <div>
            <div className="text-[10px] font-mono text-white/30 uppercase tracking-widest">Channel {channel}</div>
            <div className="text-sm font-bold text-white">{clientName}</div>
          </div>
        </div>
        <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/10 text-white/30 hover:text-white"><X size={14} /></button>
      </div>

      {/* FADER + EQ */}
      <div className="flex gap-4 px-4 py-4">
        <div className="flex gap-3 items-end">
          <Fader value={settings.gain} onChange={v => update("gain", v)} color={color} />
          <VU level={audioLevel} />
        </div>
        <div className="flex-1 flex flex-col gap-4">
          <div>
            <div className="text-[8px] text-white/20 uppercase tracking-widest mb-3">Equalizer</div>
            <div className="flex justify-between">
              {([["high","HI 8k"],["mid","MID 1k"],["low","LO 200"]] as const).map(([b, l]) => (
                <Knob key={b} value={settings.eq[b]} min={-12} max={12}
                  onChange={v => onChange({ ...settings, eq: { ...settings.eq, [b]: v } })}
                  color={color} size={42} label={l} unit="dB" centerZero />
              ))}
            </div>
          </div>
          <div className="rounded-xl p-3" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
            <div className="flex items-center justify-between mb-2">
              <span className="text-[8px] text-white/30 uppercase tracking-widest">Gate</span>
              <button onClick={() => update("gateEnabled", !settings.gateEnabled)}
                className="relative w-8 h-4 rounded-full" style={{ background: settings.gateEnabled ? color : "rgba(255,255,255,0.1)" }}>
                <div className="absolute top-0.5 w-3 h-3 rounded-full bg-white shadow" style={{ left: settings.gateEnabled ? "18px" : "2px", transition: "left 0.15s" }} />
              </button>
            </div>
            <Knob value={settings.gateThreshold} min={-100} max={0} onChange={v => update("gateThreshold", v)}
              color={settings.gateEnabled ? color : "#444"} size={36} label="Threshold" unit="dB" />
          </div>
        </div>
      </div>

      {/* MUTE */}
      <div className="px-4 pb-3">
        <button onClick={() => update("mute", !settings.mute)}
          className="w-full py-2 rounded-xl text-xs font-bold uppercase tracking-widest"
          style={settings.mute
            ? { background: "#ef444420", border: "1px solid #ef4444", color: "#ef4444" }
            : { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.4)" }}>
          {settings.mute ? "● MUTED" : "MUTE"}
        </button>
      </div>

      {/* TONE GENERATOR */}
      <div className="mx-3 mb-3 rounded-xl overflow-hidden"
        style={{ border: `1px solid ${toneActive ? color + "60" : "rgba(255,255,255,0.06)"}` }}>

        <button onClick={() => setShowTone(p => !p)} className="w-full flex items-center justify-between px-3 py-2"
          style={{ background: toneActive ? color + "15" : "rgba(255,255,255,0.03)" }}>
          <div className="flex items-center gap-2">
            <Radio size={11} className={toneActive ? "text-green-400" : "text-white/30"} />
            <span className="text-[9px] uppercase tracking-widest text-white/30">Tone Generator</span>
          </div>
          <div className="flex items-center gap-2">
            {toneActive && (
              <span className="text-[8px] px-1.5 py-0.5 rounded font-bold animate-pulse"
                style={pttHeld
                  ? { background: "#22c55e20", color: "#22c55e" }
                  : toneMode === "manual"
                    ? { background: "#3b82f620", color: "#3b82f6" }
                    : { background: "#22c55e20", color: "#22c55e" }
                }>
                {pttHeld ? "SENDER" : toneMode === "manual" ? "KLAR" : "AKTIV"}
              </span>
            )}
            <span className="text-white/20 text-xs">{showTone ? "▲" : "▼"}</span>
          </div>
        </button>

        {showTone && (
          <div className="px-3 pb-3 pt-2 space-y-3" style={{ background: "rgba(0,0,0,0.3)" }}>

            {toneError && (
              <div className="px-2 py-2 rounded text-[9px]"
                style={{ background: "rgba(239,68,68,0.15)", border: "1px solid rgba(239,68,68,0.3)", color: "#ef4444" }}>
                {toneError}
              </div>
            )}

            {/* MODE */}
            <div>
              <p className="text-[8px] text-white/30 uppercase tracking-widest mb-1.5">Routing mode</p>
              <div className="grid grid-cols-2 gap-1">
                <button
                  onClick={() => { setToneMode("auto"); if (gActive) gMode = "auto" }}
                  className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-[9px] font-bold"
                  style={toneMode === "auto"
                    ? { background: color + "30", border: `1px solid ${color}`, color }
                    : { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.4)" }}>
                  <Zap size={10} /> Auto
                </button>
                <button
                  onClick={() => { setToneMode("manual"); if (gActive) gMode = "manual" }}
                  className="flex items-center justify-center gap-1.5 py-2 rounded-lg text-[9px] font-bold"
                  style={toneMode === "manual"
                    ? { background: "#3b82f630", border: "1px solid #3b82f6", color: "#3b82f6" }
                    : { background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.4)" }}>
                  <Hand size={10} /> Manuelt
                </button>
              </div>
              <p className="text-[8px] text-white/20 mt-1">
                {toneMode === "auto" ? "Sendes automatisk til alle forbundne" : "Hold SEND-knappen nede for at sende"}
              </p>
            </div>

            {/* WAVE */}
            <div className="grid grid-cols-4 gap-1">
              {WAVES.map(w => (
                <button key={w} onClick={() => handleWave(w)} className="py-1 text-[9px] rounded capitalize font-medium"
                  style={wave === w
                    ? { background: color+"30", border: `1px solid ${color}`, color }
                    : { background: "rgba(255,255,255,0.05)", border: "1px solid transparent", color: "rgba(255,255,255,0.3)" }}>
                  {w === "sawtooth" ? "Saw" : w[0].toUpperCase() + w.slice(1)}
                </button>
              ))}
            </div>

            {/* KNOBS */}
            <div className="flex justify-around">
              <Knob value={freq} min={20} max={20000} onChange={handleFreq} color={color} size={44} label="Freq" unit="Hz" />
              <Knob value={toneLevel} min={0} max={100} onChange={handleLevel} color={color} size={44} label="Level" unit="%" />
            </div>

            {/* FREQ PRESETS */}
            <div className="flex gap-1">
              {[100,440,1000,5000,10000].map(f => (
                <button key={f} onClick={() => handleFreq(f)} className="flex-1 py-1 text-[8px] rounded"
                  style={{
                    background: freq===f ? color+"30" : "rgba(255,255,255,0.04)",
                    color: freq===f ? color : "rgba(255,255,255,0.2)",
                    border: `1px solid ${freq===f ? color+"60" : "transparent"}`
                  }}>
                  {f >= 1000 ? `${f/1000}k` : f}
                </button>
              ))}
            </div>

            {/* START/STOP */}
            <button onClick={handleToneClick}
              className="w-full py-3 rounded-lg text-sm font-black uppercase tracking-widest"
              style={toneActive
                ? { background: "#ef4444", color: "white", boxShadow: "0 0 20px #ef444480" }
                : { background: color, color: "white", boxShadow: `0 0 20px ${color}80` }}>
              {toneActive ? "■ STOP TONE" : "▶ START TONE"}
            </button>

            {/* 🔥 PTT BUTTON – only shown in manual mode when tone is active */}
            {toneActive && toneMode === "manual" && (
              <button
                onPointerDown={handlePttDown}
                onPointerUp={handlePttUp}
                onPointerCancel={handlePttUp}
                className="w-full py-4 rounded-xl font-black uppercase tracking-widest text-sm flex items-center justify-center gap-2 touch-none select-none"
                style={pttHeld
                  ? { background: "#22c55e", color: "white", boxShadow: "0 0 24px #22c55e80" }
                  : { background: "rgba(59,130,246,0.2)", border: "2px solid #3b82f6", color: "#3b82f6" }
                }
              >
                <Mic size={16} />
                {pttHeld ? "SENDER..." : "HOLD FOR AT SENDE"}
              </button>
            )}

          </div>
        )}
      </div>

      {/* FOOTER */}
      <div className="px-4 py-1.5 flex items-center justify-between"
        style={{ background: "rgba(0,0,0,0.5)", borderTop: "1px solid rgba(255,255,255,0.04)" }}>
        <span className="text-[7px] font-mono text-white/15">CH{channel} · {clientName}</span>
        <span className="text-[7px] font-mono"
          style={{ color: clientId && clientId !== "0" ? "rgba(34,197,94,0.5)" : "rgba(239,68,68,0.7)" }}>
          ID: {clientId || "MANGLER"}
        </span>
      </div>

    </div>
  )
}

export default ChannelMixer
