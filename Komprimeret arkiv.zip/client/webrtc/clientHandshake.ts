import { Socket } from "socket.io-client"

let socket: Socket | null = null
let localStream: MediaStream | null = null

export function setSocket(s: Socket) {
  socket = s
}

export function registerClient(client: {
  id: string
  name: string
  type: "mobile" | "desktop" | "aux"
}) {

  if (!socket) return

  socket.emit("client:register", client, (res: any) => {
    if (!res?.ok) {
      console.error("REGISTER FAILED")
    }
  })

}

export async function attachMicrophone() {

  if (!socket) return

  localStream = await navigator.mediaDevices.getUserMedia({
    audio: true
  })

  socket.emit("client:mic-attached", { ok: true })

  return localStream
}

export async function createProducer(device: any, transport: any, clientId: string) {

  if (!localStream) return

  const track = localStream.getAudioTracks()[0]

  const producer = await transport.produce({ track })

  socket?.emit("producer:register", {
    clientId,
    producerId: producer.id
  })

  return producer
}

import { getDevice, getSendTransport } from "./mediasoupClient"

export async function startAudio(clientId: string) {

  const device = getDevice()
  const transport = getSendTransport()

  return await createProducer(device, transport, clientId)

}