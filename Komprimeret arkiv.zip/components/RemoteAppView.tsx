import React, { useState, useEffect, useRef } from 'react';
import { Mic, Radio, Activity, Lock, Settings, PhoneOff, Anchor, Sliders, Volume2, ShieldCheck, X, Palette, Maximize2, Grid, Video, VideoOff, GripHorizontal, Minimize2, Music, SlidersHorizontal, GripVertical, Layers, Check, ChevronDown } from 'lucide-react';
import { Client, MappedClient } from '../types';

interface RemoteAppViewProps {
  clients: Client[];
  updateClient?: (id: string, updates: Partial<Client>) => void;
  mappings: (MappedClient | null)[];
  theme: 'orange' | 'blue';
  panelName?: string;
  sharedStream1: MediaStream | null;
  sharedStream2: MediaStream | null;
  onTalkToggle?: (slotIdx: number, val: boolean) => void;
}

const RemoteAppView: React.FC<RemoteAppViewProps> = ({ 
  clients, updateClient, mappings, theme, panelName = "STATION_ALPHA_PAD",
  sharedStream1, sharedStream2, onTalkToggle
}) => {
  const [activeTalks, setActiveTalks] = useState<boolean[]>(new Array(64).fill(false));
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  
  const [availableMics, setAvailableMics] = useState<MediaDeviceInfo[]>([]);
  const [selectedMicId, setSelectedMicId] = useState<string>('');
  const [localMicLevel, setLocalMicLevel] = useState(-60);
  const micStreamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyzerRef = useRef<AnalyserNode | null>(null);

  const themeColor = theme === 'orange' ? 'orange' : 'blue';

  useEffect(() => {
    const getDevices = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputs = devices.filter(d => d.kind === 'audioinput');
        setAvailableMics(audioInputs);
        if (audioInputs.length > 0 && !selectedMicId) setSelectedMicId(audioInputs[0].deviceId);
      } catch (e) {}
    };
    getDevices();
  }, [selectedMicId]);

  useEffect(() => {
    const startMic = async () => {
      if (micStreamRef.current) micStreamRef.current.getTracks().forEach(t => t.stop());
      if (!selectedMicId) return;
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: { deviceId: { exact: selectedMicId } } });
        micStreamRef.current = stream;
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        audioCtxRef.current = ctx;
        const analyzer = ctx.createAnalyser(); analyzer.fftSize = 256;
        ctx.createMediaStreamSource(stream).connect(analyzer);
        analyzerRef.current = analyzer;
        const update = () => {
          if (!analyzerRef.current) return;
          const data = new Uint8Array(analyzer.frequencyBinCount);
          analyzerRef.current.getByteFrequencyData(data);
          const avg = data.reduce((a, b) => a + b, 0) / data.length;
          setLocalMicLevel(avg > 0 ? (avg / 255) * 60 - 60 : -60);
          requestAnimationFrame(update);
        };
        update();
      } catch (err) { console.error("Mic error:", err); }
    };
    startMic();
    return () => { micStreamRef.current?.getTracks().forEach(t => t.stop()); audioCtxRef.current?.close(); };
  }, [selectedMicId]);

  const handleTalkToggle = (idx: number, val: boolean) => {
    const mapping = mappings[idx];
    if (!mapping) return;
    const newActive = [...activeTalks];
    newActive[idx] = val;
    setActiveTalks(newActive);
    onTalkToggle?.(idx, val);
    if (updateClient && mapping.id) updateClient(mapping.id, { isTalking: val });
  };

  return (
    <div className="h-full bg-black flex flex-col selection:bg-none select-none overflow-hidden brushed-metal relative w-full">
      <div className="h-16 bg-zinc-900 border-b-2 border-black flex items-center justify-between px-6 shrink-0 z-[100]">
        <div className="flex items-center gap-6">
           <div className={`p-2 rounded bg-${themeColor}-600 shadow-lg bevel no-active`}><Radio size={20} className="text-white" /></div>
           <div className="flex flex-col">
              <span className="text-white font-black text-sm uppercase tracking-tighter italic leading-none">{panelName}</span>
              <span className="text-[9px] text-zinc-500 font-bold uppercase tracking-[0.3em] mt-1 italic">LOCAL_NETWORK_PEER</span>
           </div>
        </div>
        <div className="flex items-center gap-6">
           <div className="flex items-center gap-4 bg-black/40 px-5 py-2 rounded-2xl border border-white/5">
              <Mic size={14} className={localMicLevel > -15 ? "text-red-500" : "text-zinc-500"} />
              <div className="h-2 w-24 bg-zinc-950 rounded-full overflow-hidden border border-white/5">
                 <div className={`h-full transition-all duration-75 ${localMicLevel > -10 ? 'bg-red-500' : 'bg-green-500'}`} style={{ width: `${Math.max(2, (localMicLevel + 60) * 1.66)}%` }} />
              </div>
           </div>
           <button onClick={() => setIsSettingsOpen(true)} className="p-2 text-zinc-500 hover:text-white transition-all"><Settings size={22} /></button>
        </div>
      </div>

      <div className="flex-1 p-8 bg-zinc-950 overflow-y-auto custom-scrollbar">
        <div className="grid grid-cols-8 gap-4 w-full">
          {mappings.slice(0, 32).map((mapping, i) => {
            const isAssigned = !!mapping;
            const targetClient = mapping ? clients.find(c => c.id === mapping.id) : null;
            const isTalking = !!(targetClient?.isTalking || targetClient?.isLatched);
            return (
              <div 
                key={i} 
                onMouseDown={() => isAssigned && handleTalkToggle(i, true)}
                onMouseUp={() => isAssigned && handleTalkToggle(i, false)}
                className={`relative aspect-square rounded-2xl border-2 transition-all duration-100 flex flex-col items-center justify-center bevel no-active cursor-pointer ${!isAssigned ? 'opacity-5 bg-black/20' : isTalking ? `shadow-[0_0_40px_rgba(255,255,255,0.2)] brightness-125 border-white` : 'border-white/10 bg-zinc-900/60'}`} 
                style={{ backgroundColor: isAssigned ? (isTalking ? mapping.color : `${mapping.color}CC`) : 'transparent' }}
              >
                {isAssigned && <span className="font-black text-white uppercase text-xs text-center drop-shadow-md">{mapping.name}</span>}
              </div>
            );
          })}
        </div>
      </div>
      
      {isSettingsOpen && (
        <div className="fixed inset-0 z-[5000] bg-black/90 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
           <div className="w-full max-w-lg bg-zinc-900 border border-white/10 rounded-[2.5rem] p-8 space-y-6">
              <h3 className="text-xl font-black text-white uppercase italic">Pad Settings</h3>
              <div className="space-y-4">
                 <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Select Microphone Interface</label>
                 <select value={selectedMicId} onChange={(e) => setSelectedMicId(e.target.value)} className="w-full bg-black border border-white/10 rounded-xl p-4 text-xs font-black text-white">
                    {availableMics.map(mic => <option key={mic.deviceId} value={mic.deviceId}>{mic.label || 'Mic Path'}</option>)}
                 </select>
              </div>
              <button onClick={() => setIsSettingsOpen(false)} className={`w-full py-5 bg-${themeColor}-600 text-white font-black rounded-2xl uppercase bevel`}>Update Pad</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default RemoteAppView;