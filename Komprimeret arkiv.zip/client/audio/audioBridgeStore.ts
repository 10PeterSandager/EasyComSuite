/**
 * audioBridgeStore.ts
 * Placér i: client/audio/audioBridgeStore.ts
 */

import { socket } from "../webrtc/intercom"
import { startAudioBridge, stopAudioBridge, setAudioBridgeLevelCallback, isAudioBridgeLive } from "./AudioBridge"

type BridgeStatus = "idle" | "starting" | "active" | "error"

type BridgeState = {
  status: BridgeStatus
  deviceIndex: number | null
  channelIndex: number
  deviceName: string
  level: number
  error: string | null
  stream: MediaStream | null
}

const state: BridgeState = {
  status: "idle",
  deviceIndex: null,
  channelIndex: 0,
  deviceName: "",
  level: 0,
  error: null,
  stream: null,
}

const listeners = new Set<(s: BridgeState) => void>()

export function subscribeBridge(fn: (s: BridgeState) => void): () => void {
  listeners.add(fn)
  fn({ ...state })
  // Return ONLY unsubscribe – never stop the bridge
  return () => listeners.delete(fn)
}

function notify() {
  listeners.forEach(fn => fn({ ...state }))
}

// 🔥 Returns stream only if track is actually live
export function getBridgeStream(): MediaStream | null {
  if (!state.stream) return null
  if (!isAudioBridgeLive()) {
    console.warn("getBridgeStream: track is ended – bridge needs restart")
    return null
  }
  return state.stream
}

export function getBridgeStatus(): BridgeStatus {
  return state.status
}

export async function startBridge(
  deviceIndex: number,
  channelIndex: number,
  deviceName: string
): Promise<void> {
  if (state.status === "active") {
    await stopBridge()
  }

  state.status = "starting"
  state.deviceIndex = deviceIndex
  state.channelIndex = channelIndex
  state.deviceName = deviceName
  state.error = null
  notify()

  return new Promise((resolve, reject) => {
    socket.emit("audio:capture:start", {
      deviceIndex,
      channelIndex,
      sampleRate: 48000
    }, async (res: any) => {
      if (!res?.ok) {
        state.status = "error"
        state.error = res?.error ?? "Fejl ved capture start"
        notify()
        reject(new Error(state.error!))
        return
      }

      try {
        const stream = await startAudioBridge(res.sampleRate ?? 48000)

        // 🔥 Verify track is live immediately after creation
        const track = stream.getAudioTracks()[0]
        console.log(`🎙 Bridge track state after start: ${track?.readyState}`)

        if (!track || track.readyState !== "live") {
          throw new Error(`Bridge track not live after start: ${track?.readyState}`)
        }

        setAudioBridgeLevelCallback((level: number) => {
          state.level = level
          notify()
        })

        state.stream = stream
        state.status = "active"
        state.error = null
        notify()

        socket.emit("producer:input:set", {
          label: `${deviceName} CH${channelIndex + 1}`,
          channel: channelIndex + 1
        })

        console.log(`✅ Bridge active: ${deviceName} CH${channelIndex + 1} – track: ${track.readyState}`)
        resolve()

      } catch (e: any) {
        state.status = "error"
        state.error = e.message
        state.stream = null
        notify()
        socket.emit("audio:capture:stop")
        reject(e)
      }
    })
  })
}

export async function stopBridge(): Promise<void> {
  socket.emit("audio:capture:stop")
  stopAudioBridge()
  socket.emit("producer:input:clear", {})

  state.status = "idle"
  state.stream = null
  state.level = 0
  state.error = null
  notify()
}
