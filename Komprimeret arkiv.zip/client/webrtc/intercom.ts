import { io, Socket } from "socket.io-client"
import { createMixer } from "../audio/AudioMixer"
import { getDevice, getRecvTransport } from "./mediasoupClient"

/* ---------- SOCKET ---------- */

export const socket: Socket = io("http://localhost:3000")

export function connectToServer() {
  if (!socket.connected) socket.connect()
}

/* ---------- MICROPHONE ---------- */

export async function startMicrophone() {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
  return stream
}

/* ============================================================
   AUDIO LEVEL SYSTEM
   ============================================================ */

let audioLevels: Record<string, number> = {}

type LevelListener = (levels: Record<string, number>) => void
const levelListeners = new Set<LevelListener>()

export function subscribeToLevels(fn: LevelListener): () => void {
  levelListeners.add(fn)
  fn({ ...audioLevels })
  return () => levelListeners.delete(fn)
}

function pushLevel(key: string, value: number) {
  audioLevels[key] = value
  levelListeners.forEach(fn => fn({ ...audioLevels }))
}

export function resetLevel(key: string) {
  audioLevels[key] = 0
  levelListeners.forEach(fn => fn({ ...audioLevels }))
}

socket.on("audio:levels", (levels: Record<string, number>) => {
  Object.assign(audioLevels, levels)
  levelListeners.forEach(fn => fn({ ...audioLevels }))
})

export function getAudioLevel(id: string) {
  return audioLevels[id] || 0
}

/* ---------- RMS HELPER ---------- */

function rmsFromAnalyser(analyser: AnalyserNode): number {
  const buf = new Float32Array(analyser.fftSize)
  analyser.getFloatTimeDomainData(buf)
  let sum = 0
  for (let i = 0; i < buf.length; i++) sum += buf[i] * buf[i]
  return Math.min(100, Math.max(0, Math.sqrt(sum / buf.length) * 350))
}

/* ---------- MICROPHONE LEVEL METER ---------- */

export function startLevelMeter(stream: MediaStream, clientId: string): () => void {
  const ctx = new AudioContext()
  ctx.resume()
  const src = ctx.createMediaStreamSource(stream)
  const analyser = ctx.createAnalyser()
  analyser.fftSize = 2048
  analyser.smoothingTimeConstant = 0.4
  src.connect(analyser)

  let raf: number
  let stopped = false

  function tick() {
    if (stopped) return
    const level = rmsFromAnalyser(analyser)
    pushLevel(clientId, level)
    socket.emit("audio:level", { clientId, level })
    raf = requestAnimationFrame(tick)
  }

  raf = requestAnimationFrame(tick)

  return () => {
    stopped = true
    cancelAnimationFrame(raf)
    ctx.close()
    resetLevel(clientId)
  }
}

/* ---------- TONE LEVEL METER ---------- */

let toneRaf: number | null = null
let toneMeterClientId: string | null = null

export function startToneLevelMeter(analyser: AnalyserNode, clientId: string) {
  stopToneLevelMeter()
  toneMeterClientId = clientId

  function tick() {
    const level = rmsFromAnalyser(analyser)
    pushLevel(clientId, level)
    socket.emit("audio:level", { clientId, level })
    toneRaf = requestAnimationFrame(tick)
  }

  tick()
}

export function stopToneLevelMeter() {
  if (toneRaf !== null) {
    cancelAnimationFrame(toneRaf)
    toneRaf = null
  }
  if (toneMeterClientId) {
    resetLevel(toneMeterClientId)
    socket.emit("audio:level", { clientId: toneMeterClientId, level: 0 })
    toneMeterClientId = null
  }
}

/* ---------- RECEIVE LEVEL METER ---------- */

const recvRafs = new Map<string, number>()

export function startReceiveLevelMeter(stream: MediaStream, sourceId: string) {
  const existing = recvRafs.get(sourceId)
  if (existing) cancelAnimationFrame(existing)

  const src = audioCtx.createMediaStreamSource(stream)
  const analyser = audioCtx.createAnalyser()
  analyser.fftSize = 2048
  analyser.smoothingTimeConstant = 0.4
  src.connect(analyser)

  function tick() {
    const level = rmsFromAnalyser(analyser)
    pushLevel(`recv_${sourceId}`, level)
    const raf = requestAnimationFrame(tick)
    recvRafs.set(sourceId, raf)
  }

  tick()
}

/* ---------- AUDIO CONTEXT ---------- */

export const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)()
const mixers: Record<number, any> = {}
let muted = false

export function setMuted(state: boolean) { muted = state }

// setMediasoup() removed – consume() calls getDevice/getRecvTransport directly

/* ---------- ROUTING ---------- */

let routing: Record<number, string[]> = {}
const consumers = new Map<string, any>()
const consumerChannels = new Map<string, number>()

export function initRouting(clientId: string) {
  console.log(`[ROUTING] initRouting called for clientId: "${clientId}"`)

  socket.on("routing:update", async (connections: any[]) => {
    console.log(`[ROUTING] routing:update received – ${connections.length} total connections`)

    const toMe = connections.filter(c => c.to === clientId)
    console.log(`[ROUTING] connections TO me (${clientId}):`, toMe)

    const newRouting: Record<number, string[]> = {}
    connections.forEach(c => {
      if (c.to !== clientId) return
      if (!newRouting[c.channel]) newRouting[c.channel] = []
      newRouting[c.channel].push(c.from)
    })

    console.log(`[ROUTING] newRouting:`, newRouting)

    cleanupConsumers(newRouting)
    routing = newRouting
    await applyRouting()
  })
}

/* ---------- CLEANUP ---------- */

function cleanupConsumers(newRouting: Record<number, string[]>) {
  const active = new Set<string>()
  Object.values(newRouting).forEach(arr => arr.forEach(id => active.add(id)))

  for (const [id, consumer] of consumers.entries()) {
    const newChannel = Object.entries(newRouting).find(([_, arr]) => arr.includes(id))?.[0]
    const currentChannel = consumerChannels.get(id)

    if (!active.has(id)) {
      try { consumer.close() } catch {}
      consumers.delete(id)
      consumerChannels.delete(id)
      resetLevel(`recv_${id}`)
      continue
    }
    if (newChannel && Number(newChannel) !== currentChannel) {
      try { consumer.close() } catch {}
      consumers.delete(id)
      consumerChannels.delete(id)
    }
  }
}

/* ---------- APPLY ROUTING ---------- */

async function applyRouting() {
  console.log(`[ROUTING] applyRouting – routing:`, routing)
  for (const channelStr in routing) {
    const channel = Number(channelStr)
    for (const source of routing[channel] || []) {
      await consume(source, channel)
    }
  }
}

/* ---------- CONSUME ---------- */

async function consume(sourceId: string, channel: number) {
  // Already consuming this source on this channel
  if (consumers.has(sourceId) && consumerChannels.get(sourceId) === channel) {
    console.log(`[CONSUME] already consuming ${sourceId} on ch${channel} – skip`)
    return
  }

  // 🔥 Always get fresh references – never use cached local vars
  const device = getDevice()
  const recvTransport = getRecvTransport()

  console.log(`[CONSUME] sourceId="${sourceId}" ch=${channel} | device=${!!device} recvTransport=${!!recvTransport}`)

  if (!device || !recvTransport) {
    console.warn(`[CONSUME] ❌ mediasoup not ready for ${sourceId} – will retry on next routing:update`)
    return
  }

  try {
    console.log(`[CONSUME] → emit consume:request for "${sourceId}"`)

    const result = await new Promise<any>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error(`consume timeout for ${sourceId}`)), 8000)
      socket.emit("consume:request", {
        targetId: sourceId,
        rtpCapabilities: device.rtpCapabilities,
        transportId: recvTransport.id
      }, (res: any) => {
        clearTimeout(t)
        console.log(`[CONSUME] consume:request response for "${sourceId}":`, res)
        resolve(res)
      })
    })

    if (!result || result.error) {
      console.warn(`[CONSUME] ❌ server error for ${sourceId}:`, result?.error)
      return
    }

    const { id, producerId, kind, rtpParameters } = result

    if (!id || !producerId || !rtpParameters) {
      console.warn(`[CONSUME] ❌ incomplete response for ${sourceId}:`, result)
      return
    }

    console.log(`[CONSUME] → recvTransport.consume for "${sourceId}" producerId="${producerId}"`)

    const consumer = await recvTransport.consume({ id, producerId, kind, rtpParameters })

    if (consumer.resume) {
      await consumer.resume()
      console.log(`[CONSUME] ✅ consumer resumed for "${sourceId}"`)
    }

    consumers.set(sourceId, consumer)
    consumerChannels.set(sourceId, channel)

    const stream = new MediaStream([consumer.track])
    startReceiveLevelMeter(stream, sourceId)
    routeToChannel(stream, channel)

    console.log(`[CONSUME] ✅ consuming "${sourceId}" → ch${channel} | track state: ${consumer.track.readyState}`)

  } catch (e) {
    console.error(`[CONSUME] ❌ exception for "${sourceId}":`, e)
  }
}

/* ---------- MIXER ---------- */

function getMixer(channel: number) {
  if (!mixers[channel]) mixers[channel] = createMixer(audioCtx)
  return mixers[channel]
}

function routeToChannel(stream: MediaStream, channel: number) {
  if (muted) {
    console.log(`[MIXER] muted – skipping ch${channel}`)
    return
  }
  console.log(`[MIXER] adding stream to ch${channel}`)
  getMixer(channel).addStream(stream)
}

/* ---------- HELPERS ---------- */

export function talkback(targetId: string, myId: string, channel = 1) {
  socket.emit("connection:create", { from: myId, to: targetId, channel, replace: true })
}

export function createConnection(from: string, to: string, channel: number) {
  socket.emit("connection:create", { from, to, channel, replace: true })
}

export function removeConnection(from: string, to: string, channel: number) {
  socket.emit("connection:remove", { from, to, channel })
}

export function getConnections(cb: (c: any[]) => void) {
  socket.emit("connections:list", cb)
}

const channelLabels: Record<number, string> = {}
export function setChannelLabel(ch: number, label: string) { channelLabels[ch] = label }
export function getChannelLabel(ch: number) { return channelLabels[ch] || `Channel ${ch}` }

type Preset = { name: string; routing: Record<number, string[]> }
const presets: Preset[] = []
export function savePreset(name: string) { presets.push({ name, routing: JSON.parse(JSON.stringify(routing)) }) }
export function loadPreset(name: string, myId: string) {
  const p = presets.find(p => p.name === name)
  if (!p) return
  Object.entries(p.routing).forEach(([ch, srcs]) => {
    srcs.forEach(s => socket.emit("connection:create", { from: myId, to: s, channel: Number(ch), replace: true }))
  })
}
export function getPresets() { return presets }
